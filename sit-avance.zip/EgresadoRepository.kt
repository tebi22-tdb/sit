package com.sit_titulacion.sit.repository

import com.sit_titulacion.sit.domain.Egresado
import org.bson.types.ObjectId
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.data.mongodb.repository.Query
import org.springframework.stereotype.Repository
import java.time.Instant

@Repository
interface EgresadoRepository : MongoRepository<Egresado, ObjectId> {

    @Query("{ 'numero_control' : ?0 }")
    fun findByNumeroControl(numeroControl: String): Egresado?

    /** Buscar por número de control (contiene el texto, sin distinguir mayúsculas). */
    @Query("{ 'numero_control' : { \$regex: ?0, \$options: 'i' } }")
    fun findByNumeroControlContaining(numeroControl: String): List<Egresado>

    /** Buscar por rango de fecha de Anexo XXXI (documentos.anexo_xxxi.fecha_registro). */
    @Query(value = "{ 'documentos.anexo_xxxi.fecha_registro' : { \$gte: ?0, \$lte: ?1 } }", sort = "{ '_id' : -1 }")
    fun findByAnexoXxxiFechaRegistroBetweenOrderByIdDesc(fechaDesde: Instant, fechaHasta: Instant): List<Egresado>

    /** Buscar por número de control Y rango de fecha de Anexo XXXI. */
    @Query(value = "{ 'numero_control' : { \$regex: ?0, \$options: 'i' }, 'documentos.anexo_xxxi.fecha_registro' : { \$gte: ?1, \$lte: ?2 } }", sort = "{ '_id' : -1 }")
    fun findByNumeroControlContainingAndAnexoXxxiFechaRegistroBetween(numeroControl: String, fechaDesde: Instant, fechaHasta: Instant): List<Egresado>

    /** Buscar por rango de fecha de Constancia (documentos.constancia_no_inconveniencia.fecha_expedicion). */
    @Query(value = "{ 'documentos.constancia_no_inconveniencia.fecha_expedicion' : { \$gte: ?0, \$lte: ?1 } }", sort = "{ '_id' : -1 }")
    fun findByConstanciaFechaExpedicionBetweenOrderByIdDesc(fechaDesde: Instant, fechaHasta: Instant): List<Egresado>

    /** Buscar por número de control Y rango de fecha de Constancia. */
    @Query(value = "{ 'numero_control' : { \$regex: ?0, \$options: 'i' }, 'documentos.constancia_no_inconveniencia.fecha_expedicion' : { \$gte: ?1, \$lte: ?2 } }", sort = "{ '_id' : -1 }")
    fun findByNumeroControlContainingAndConstanciaFechaExpedicionBetween(numeroControl: String, fechaDesde: Instant, fechaHasta: Instant): List<Egresado>

    /** Enviados al departamento académico que aún no tienen registro y liberación recibido (pendientes). */
    @Query(value = "{ 'fecha_enviado_departamento_academico' : { \$exists: true, \$ne: null }, 'fecha_recibido_registro_liberacion' : null }", sort = "{ 'fecha_actualizacion' : -1 }")
    fun findByEnviadoDepartamentoPendientes(): List<Egresado>

    /** Enviados al departamento que ya tienen registro y liberación recibido (aprobados). */
    @Query(value = "{ 'fecha_recibido_registro_liberacion' : { \$exists: true, \$ne: null } }", sort = "{ 'fecha_actualizacion' : -1 }")
    fun findByRecibidoRegistroLiberacion(): List<Egresado>

    /** Todos los enviados al departamento (tienen fecha_enviado_departamento_academico). */
    @Query(value = "{ 'fecha_enviado_departamento_academico' : { \$exists: true, \$ne: null } }", sort = "{ 'fecha_actualizacion' : -1 }")
    fun findByEnviadoDepartamentoTodos(): List<Egresado>
}
