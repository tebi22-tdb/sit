rootProject.name = "sit"
