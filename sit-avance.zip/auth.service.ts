import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';

export interface UsuarioActual {
  username: string;
  rol: string;
}

const AUTH = `${environment.apiUrl}/api/auth`;
const API = `${environment.apiUrl}/api`;

export interface CrearUsuarioBody {
  nombre: string;
  rol: string;
  correo_electronico: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private usuario: UsuarioActual | null = null;

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<UsuarioActual> {
    const body = new URLSearchParams();
    body.set('username', username);
    body.set('password', password);
    return this.http
      .post<UsuarioActual>(AUTH + '/login', body.toString(), {
        withCredentials: true,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      })
      .pipe(tap((u) => (this.usuario = u)));
  }

  me(): Observable<UsuarioActual> {
    return this.http
      .get<UsuarioActual>(AUTH + '/me', { withCredentials: true })
      .pipe(tap((u) => (this.usuario = u)));
  }

  logout(): Observable<unknown> {
    return this.http.post(AUTH + '/logout', {}, { withCredentials: true }).pipe(
      tap(() => (this.usuario = null))
    );
  }

  getUsuario(): UsuarioActual | null {
    return this.usuario;
  }

  isCoordinador(): boolean {
    const r = this.usuario?.rol?.toLowerCase();
    return r === 'coordinador' || r === 'apoyo_titulacion' || r === 'apoyo titulacion';
  }

  isEgresado(): boolean {
    return this.usuario?.rol?.toLowerCase() === 'egresado';
  }

  isAcademico(): boolean {
    return this.usuario?.rol?.toLowerCase() === 'academico';
  }

  /** Crea un usuario de personal (solo coordinador). Envía credenciales al correo. */
  crearUsuario(body: CrearUsuarioBody): Observable<{ ok: boolean; message?: string; error?: string }> {
    return this.http.post<{ ok: boolean; message?: string; error?: string }>(API + '/usuarios', body, {
      withCredentials: true,
    });
  }
}
