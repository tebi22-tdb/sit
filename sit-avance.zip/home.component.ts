import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../layout/header/header.component';
import { NuevoEgresadoComponent } from './nuevo-egresado/nuevo-egresado.component';
import { EgresadoForm } from '../../core/datos';
import { EgresadoService, EgresadoItem, EgresadoDetail } from '../../services/egresado.service';
import { AuthService, CrearUsuarioBody } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent, NuevoEgresadoComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent implements OnInit {
  mostrarFormulario = false;
  editando = false;
  mensaje = '';
  lista: EgresadoItem[] = [];
  textoBusqueda = '';
  mostrarFiltro = false;
  fechaDesde = '';
  fechaHasta = '';
  tipoFiltroFecha = 'anexo_xxxi'; // 'anexo_xxxi' | 'constancia'
  detalle: EgresadoDetail | null = null;
  cargandoDetalle = false;
  cargandoLista = false;
  errorLista = '';
  enviandoEnviar = false;
  confirmandoRecibidos = false;
  creandoAnexo91 = false;
  confirmandoEntregaAnexo91 = false;
  confirmandoRecibidoAnexo92 = false;
  creandoAnexo92 = false;
  solicitandoSinodales = false;
  confirmandoSinodalesRecibidos = false;
  mostrandoModalAgendar93 = false;
  agendandoActo93 = false;
  creandoAnexo93 = false;
  fechaAgendar93 = '';

  mostrarModalAgregarUsuario = false;
  usuarioForm: CrearUsuarioBody = {
    nombre: '',
    rol: 'coordinador',
    correo_electronico: '',
  };
  guardandoUsuario = false;
  mensajeUsuario = '';

  /** Solo el coordinador (no servicios_escolares) puede agregar usuarios. */
  get esCoordinador(): boolean {
    return this.authService.getUsuario()?.rol?.toLowerCase() === 'coordinador';
  }

  get esResidenciaProfesional(): boolean {
    return (this.detalle?.datos_proyecto?.modalidad ?? '').trim().toLowerCase() === 'residencia profesional';
  }

  // (Ya no bloqueamos en frontend por rol; la validación real se hace en backend.)

  get puedeEnviar(): boolean {
    return !!this.detalle && this.esResidenciaProfesional && !this.detalle.fecha_enviado_departamento_academico;
  }

  get puedeConfirmar(): boolean {
    return !!this.detalle
      && this.esResidenciaProfesional
      && !!this.detalle.fecha_recibido_registro_liberacion
      && !this.detalle.fecha_confirmacion_recibidos_anexo_xxxi_xxxii;
  }

  get puedeCrear91(): boolean {
    return !!this.detalle
      && this.esResidenciaProfesional
      && !!this.detalle.fecha_confirmacion_recibidos_anexo_xxxi_xxxii;
  }

  /** Pasos del proceso (panel derecho). Solo acciones cuando corresponde al flujo. */
  get pasosProceso(): {
    label: string;
    completado: boolean;
    activo: boolean;
    fecha: string;
    accion?:
      | 'enviar'
      | 'confirmar'
      | 'crear_91'
      | 'confirmar_entrega_91'
      | 'crear_92'
      | 'confirmar_recibido_92'
      | 'solicitar_sinodales'
      | 'confirmar_sinodales_recibidos'
      | 'agendar_93'
      | 'crear_93';
  }[] {
    if (!this.detalle || !this.esResidenciaProfesional) return [];
    const d = this.detalle;

    const completados = [
      !!d.fecha_enviado_departamento_academico,
      !!d.fecha_confirmacion_recibidos_anexo_xxxi_xxxii,
      !!d.fecha_creacion_anexo_9_1,
      !!d.fecha_confirmacion_entrega_anexo_9_1,
      !!(d.fecha_creacion_anexo_9_2 || d.fecha_confirmacion_recibido_anexo_9_2),
      !!d.fecha_confirmacion_recibido_anexo_9_2,
      !!d.fecha_solicitud_sinodales,
      !!d.fecha_confirmacion_sinodales_recibidos,
      !!d.fecha_agenda_acto_9_3,
      !!d.fecha_creacion_anexo_9_3,
      !!d.fecha_creacion_anexo_9_3, // Proceso finalizado
    ];

    const labels = [
      'Solicitud de anexo XXXI y XXXII',
      'Recibidos anexo XXXI y XXXII',
      'Crear 9.1',
      'Entrega de anexo 9.1',
      'Crear 9.2',
      'Recibido 9.2',
      'Solicitud de sinodales',
      'Recibimos sinodales',
      'Agendar 9.3',
      'Crear anexo 9.3',
      'Proceso finalizado',
    ];

    const fechas = [
      d.fecha_enviado_departamento_academico || '—',
      d.fecha_confirmacion_recibidos_anexo_xxxi_xxxii || '—',
      d.fecha_creacion_anexo_9_1 || '—',
      d.fecha_confirmacion_entrega_anexo_9_1 || '—',
      d.fecha_creacion_anexo_9_2 || '—',
      d.fecha_confirmacion_recibido_anexo_9_2 || '—',
      d.fecha_solicitud_sinodales || '—',
      d.fecha_confirmacion_sinodales_recibidos || '—',
      d.fecha_agenda_acto_9_3 || '—',
      d.fecha_creacion_anexo_9_3 || '—',
      d.fecha_creacion_anexo_9_3 || '—',
    ];

    let activoIndex = completados.findIndex(c => !c);
    if (activoIndex < 0) activoIndex = completados.length;

    const acciones: Array<
      | 'enviar'
      | 'confirmar'
      | 'crear_91'
      | 'confirmar_entrega_91'
      | 'crear_92'
      | 'confirmar_recibido_92'
      | 'solicitar_sinodales'
      | 'confirmar_sinodales_recibidos'
      | 'agendar_93'
      | 'crear_93'
      | undefined
    > = [
      this.puedeEnviar ? 'enviar' : undefined,
      this.puedeConfirmar ? 'confirmar' : undefined,
      (this.puedeCrear91 && !d.fecha_creacion_anexo_9_1) ? 'crear_91' : undefined,
      d.fecha_creacion_anexo_9_1 && !d.fecha_confirmacion_entrega_anexo_9_1 ? 'confirmar_entrega_91' : undefined,
      d.fecha_confirmacion_entrega_anexo_9_1 &&
      !d.fecha_creacion_anexo_9_2 &&
      !d.fecha_confirmacion_recibido_anexo_9_2
        ? 'crear_92'
        : undefined,
      d.fecha_creacion_anexo_9_2 && !d.fecha_confirmacion_recibido_anexo_9_2 ? 'confirmar_recibido_92' : undefined,
      d.fecha_confirmacion_recibido_anexo_9_2 && !d.fecha_solicitud_sinodales ? 'solicitar_sinodales' : undefined,
      d.fecha_solicitud_sinodales && !d.fecha_confirmacion_sinodales_recibidos ? 'confirmar_sinodales_recibidos' : undefined,
      d.fecha_confirmacion_sinodales_recibidos && !d.fecha_agenda_acto_9_3 ? 'agendar_93' : undefined,
      d.fecha_agenda_acto_9_3 && !d.fecha_creacion_anexo_9_3 ? 'crear_93' : undefined,
      undefined,
    ];

    return labels.map((label, i) => ({
      label,
      completado: completados[i],
      activo: i === activoIndex,
      fecha: fechas[i],
      accion: acciones[i],
    }));
  }

  onPasoProcesoClick(
    accion?:
      | 'enviar'
      | 'confirmar'
      | 'crear_91'
      | 'confirmar_entrega_91'
      | 'crear_92'
      | 'confirmar_recibido_92'
      | 'solicitar_sinodales'
      | 'confirmar_sinodales_recibidos'
      | 'agendar_93'
      | 'crear_93',
  ): void {
    if (!accion) return;
    if (accion === 'enviar') this.onEnviarDepartamento();
    else if (accion === 'confirmar') this.onConfirmarRecibidos();
    else if (accion === 'crear_91') this.onCrearAnexo91();
    else if (accion === 'confirmar_entrega_91') this.onConfirmarEntregaAnexo91();
    else if (accion === 'crear_92') this.onCrearAnexo92();
    else if (accion === 'confirmar_recibido_92') this.onConfirmarRecibidoAnexo92();
    else if (accion === 'solicitar_sinodales') this.onSolicitarSinodales();
    else if (accion === 'confirmar_sinodales_recibidos') this.onConfirmarSinodalesRecibidos();
    else if (accion === 'agendar_93') this.onAbrirModalAgendar93();
    else if (accion === 'crear_93') this.onCrearAnexo93();
  }

  formatearFechaHora(iso?: string): string {
    if (!iso || iso === '—') return '—';
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return iso;
      const dia = d.getDate().toString().padStart(2, '0');
      const mes = (d.getMonth() + 1).toString().padStart(2, '0');
      const anio = d.getFullYear();
      const h = d.getHours().toString().padStart(2, '0');
      const min = d.getMinutes().toString().padStart(2, '0');
      return `${dia}/${mes}/${anio}, ${h}:${min}`;
    } catch {
      return iso;
    }
  }

  constructor(
    private egresadoService: EgresadoService,
    private authService: AuthService,
  ) {}

  ngOnInit(): void {
    this.cargarLista();
  }

  cargarLista(): void {
    this.errorLista = '';
    this.cargandoLista = true;
    const filtros: { numero_control?: string; fecha_desde?: string; fecha_hasta?: string; tipo_filtro?: string } = {};
    if (this.textoBusqueda?.trim()) filtros.numero_control = this.textoBusqueda;
    if (this.fechaDesde) filtros.fecha_desde = this.fechaDesde;
    if (this.fechaHasta) filtros.fecha_hasta = this.fechaHasta;
    if ((this.fechaDesde || this.fechaHasta) && this.tipoFiltroFecha) filtros.tipo_filtro = this.tipoFiltroFecha;
    this.egresadoService.listar(Object.keys(filtros).length ? filtros : undefined).subscribe({
      next: (lista) => {
        this.lista = lista;
        this.cargandoLista = false;
      },
      error: () => {
        this.lista = [];
        this.cargandoLista = false;
        this.errorLista = 'No se pudo cargar la lista. ¿Está el backend en ejecución?';
      },
    });
  }

  onBuscar(): void {
    this.cargarLista();
  }

  onSeleccionar(item: EgresadoItem): void {
    this.mensaje = '';
    this.detalle = null;
    this.cargandoDetalle = true;
    this.egresadoService.obtenerPorId(item.id).subscribe({
      next: (d) => {
        this.detalle = d;
        this.cargandoDetalle = false;
      },
      error: (err) => {
        if (err?.status === 404 && item.numero_control) {
          this.egresadoService.obtenerPorNumeroControl(item.numero_control).subscribe({
            next: (d) => {
              this.detalle = d;
              this.cargandoDetalle = false;
            },
            error: () => {
              this.detalle = null;
              this.cargandoDetalle = false;
              this.mensaje = 'Egresado no encontrado.';
            },
          });
        } else {
          this.detalle = null;
          this.cargandoDetalle = false;
          this.mensaje = err?.status === 404 ? 'Egresado no encontrado.' : 'No se pudo cargar el egresado.';
        }
      },
    });
  }

  cerrarDetalle(): void {
    this.detalle = null;
    this.textoBusqueda = '';
    this.cargarLista();
  }

  onAgregar(payload: { datos: EgresadoForm; archivo: File | null }): void {
    this.mensaje = '';
    this.detalle = null;
    this.egresadoService.crear(payload.datos, payload.archivo).subscribe({
      next: () => {
        this.mostrarFormulario = false;
        this.cargarLista();
        this.mensaje = 'Se registró correctamente.';
      },
      error: () => {
        this.mensaje = 'No se registró correctamente.';
      },
    });
  }

  onEnviarDepartamento(): void {
    if (!this.detalle) return;
    if (!this.esResidenciaProfesional) {
      this.mensaje = 'Este flujo aplica solo a Residencia Profesional.';
      return;
    }
    this.mensaje = '';
    this.enviandoEnviar = true;
    this.egresadoService.enviarDepartamentoAcademico(this.detalle.id).subscribe({
      next: () => {
        this.enviandoEnviar = false;
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({
          next: (d) => { this.detalle = d; },
        });
        this.mensaje = 'Enviado al departamento académico para su registro y liberación.';
      },
      error: (err) => {
        this.enviandoEnviar = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al enviar: ${msg}` : 'Error al enviar.';
      },
    });
  }

  onConfirmarRecibidos(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.confirmandoRecibidos = true;
    this.egresadoService.confirmarRecibidosAnexoXxxiXxxii(this.detalle.id).subscribe({
      next: () => {
        this.confirmandoRecibidos = false;
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Confirmado. Ya puedes crear y descargar el Anexo 9.1.';
      },
      error: (err) => {
        this.confirmandoRecibidos = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al confirmar: ${msg}` : 'Error al confirmar.';
      },
    });
  }

  onCrearAnexo91(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.creandoAnexo91 = true;
    this.egresadoService.generarAnexo91(this.detalle.id).subscribe({
      next: (blob) => {
        this.creandoAnexo91 = false;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Anexo-9.1-${this.detalle!.numero_control}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Anexo 9.1 creado y descargado.';
      },
      error: (err) => {
        this.creandoAnexo91 = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al crear 9.1: ${msg}` : 'Error al crear 9.1.';
      },
    });
  }

  onConfirmarEntregaAnexo91(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.confirmandoEntregaAnexo91 = true;
    this.egresadoService.confirmarEntregaAnexo91(this.detalle.id).subscribe({
      next: () => {
        this.confirmandoEntregaAnexo91 = false;
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Entrega de anexo 9.1 confirmada.';
      },
      error: (err) => {
        this.confirmandoEntregaAnexo91 = false;
        const status = err?.status;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        if (status === 403) {
          this.mensaje = 'No se pudo confirmar la entrega de 9.1 (sin permisos).';
        } else {
          this.mensaje = msg ? `Error al confirmar entrega 9.1: ${msg}` : 'Error al confirmar entrega 9.1.';
        }
      },
    });
  }

  onCrearAnexo92(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.creandoAnexo92 = true;
    const id = this.detalle.id;
    this.egresadoService.descargarAnexo92(id).subscribe({
      next: (blob) => {
        this.creandoAnexo92 = false;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Anexo-9.2-${this.detalle!.numero_control}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
        this.egresadoService.obtenerPorId(id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Anexo 9.2 generado y descargado.';
      },
      error: (err) => {
        this.creandoAnexo92 = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al crear 9.2: ${msg}` : 'Error al crear 9.2. Revisa plantilla y LibreOffice en el servidor.';
      },
    });
  }

  onConfirmarRecibidoAnexo92(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.confirmandoRecibidoAnexo92 = true;
    const id = this.detalle.id;

    this.egresadoService.confirmarRecibidoAnexo92(id).subscribe({
      next: () => {
        this.confirmandoRecibidoAnexo92 = false;
        this.egresadoService.obtenerPorId(id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Recibido 9.2 confirmado.';
      },
      error: (err) => {
        this.confirmandoRecibidoAnexo92 = false;
        const status = err?.status;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        if (status === 403) {
          this.mensaje = 'No se pudo confirmar el Recibido 9.2 (sin permisos).';
        } else {
          this.mensaje = msg ? `Error al confirmar recibido 9.2: ${msg}` : 'Error al confirmar recibido 9.2.';
        }
      },
    });
  }

  onSolicitarSinodales(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.solicitandoSinodales = true;
    this.egresadoService.solicitarSinodales(this.detalle.id).subscribe({
      next: () => {
        this.solicitandoSinodales = false;
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Solicitud de sinodales registrada.';
      },
      error: (err) => {
        this.solicitandoSinodales = false;
        const status = err?.status;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        if (status === 403) {
          this.mensaje = 'No se pudo solicitar sinodales (sin permisos).';
        } else {
          this.mensaje = msg ? `Error al solicitar sinodales: ${msg}` : 'Error al solicitar sinodales.';
        }
      },
    });
  }

  onConfirmarSinodalesRecibidos(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.confirmandoSinodalesRecibidos = true;
    this.egresadoService.confirmarSinodalesRecibidos(this.detalle.id).subscribe({
      next: () => {
        this.confirmandoSinodalesRecibidos = false;
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Sinodales recibidos confirmado.';
      },
      error: (err) => {
        this.confirmandoSinodalesRecibidos = false;
        const status = err?.status;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        if (status === 403) {
          this.mensaje = 'No se pudo confirmar sinodales recibidos (sin permisos).';
        } else {
          this.mensaje = msg ? `Error al confirmar sinodales recibidos: ${msg}` : 'Error al confirmar sinodales recibidos.';
        }
      },
    });
  }

  onAbrirModalAgendar93(): void {
    if (!this.detalle) return;
    this.fechaAgendar93 = '';
    this.mostrandoModalAgendar93 = true;
  }

  cerrarModalAgendar93(): void {
    this.mostrandoModalAgendar93 = false;
    this.fechaAgendar93 = '';
  }

  onConfirmarAgendar93(): void {
    if (!this.detalle) return;
    if (!this.fechaAgendar93?.trim()) {
      this.mensaje = 'Selecciona fecha y hora del acto 9.3.';
      return;
    }

    this.mensaje = '';
    this.agendandoActo93 = true;
    this.egresadoService.agendarActo93(this.detalle.id, this.fechaAgendar93).subscribe({
      next: () => {
        this.agendandoActo93 = false;
        this.cerrarModalAgendar93();
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Acto 9.3 agendado.';
      },
      error: (err) => {
        this.agendandoActo93 = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al agendar 9.3: ${msg}` : 'Error al agendar 9.3.';
      },
    });
  }

  onCrearAnexo93(): void {
    if (!this.detalle) return;
    this.mensaje = '';
    this.creandoAnexo93 = true;
    this.egresadoService.descargarAnexo93(this.detalle.id).subscribe({
      next: (blob) => {
        this.creandoAnexo93 = false;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Anexo-9.3-${this.detalle!.numero_control}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
        this.egresadoService.obtenerPorId(this.detalle!.id).subscribe({ next: (d) => { this.detalle = d; } });
        this.mensaje = 'Anexo 9.3 creado y descargado. Proceso finalizado.';
      },
      error: (err) => {
        this.creandoAnexo93 = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al crear 9.3: ${msg}` : 'Error al crear 9.3.';
      },
    });
  }

  onEliminar(): void {
    if (!this.detalle) return;
    if (!confirm(`¿Eliminar el registro de ${this.detalle.datos_personales.nombre} ${this.detalle.datos_personales.apellido_paterno}? Esta acción no se puede deshacer.`)) return;
    this.mensaje = '';
    this.egresadoService.eliminar(this.detalle.id).subscribe({
      next: () => {
        this.detalle = null;
        this.textoBusqueda = '';
        this.cargarLista();
        this.mensaje = 'Registro eliminado correctamente.';
      },
      error: (err) => {
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg ? `Error al eliminar: ${msg}` : 'Error al eliminar.';
      },
    });
  }

  onActualizar(payload: { id: string; datos: EgresadoForm; archivo: File | null }): void {
    this.mensaje = '';
    this.egresadoService.actualizar(payload.id, payload.datos, payload.archivo).subscribe({
      next: () => {
        this.editando = false;
        this.egresadoService.obtenerPorId(payload.id).subscribe({
          next: (d) => {
            this.detalle = d;
          },
        });
        this.cargarLista();
        this.mensaje = 'Egresado actualizado correctamente.';
      },
      error: (err) => {
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensaje = msg
          ? `Error al actualizar: ${msg}`
          : 'Error al actualizar. Revisa que el backend esté en marcha y MongoDB conectada.';
      },
    });
  }

  abrirModalAgregarUsuario(): void {
    this.usuarioForm = { nombre: '', rol: 'coordinador', correo_electronico: '' };
    this.mensajeUsuario = '';
    this.mostrarModalAgregarUsuario = true;
  }

  cerrarModalAgregarUsuario(): void {
    this.mostrarModalAgregarUsuario = false;
    this.mensajeUsuario = '';
  }

  guardarUsuario(): void {
    this.mensajeUsuario = '';
    if (!this.usuarioForm.correo_electronico?.trim()) {
      this.mensajeUsuario = 'El correo electrónico es obligatorio.';
      return;
    }
    this.guardandoUsuario = true;
    this.authService.crearUsuario(this.usuarioForm).subscribe({
      next: (res) => {
        this.guardandoUsuario = false;
        this.mostrarModalAgregarUsuario = false;
        this.mensaje = res?.message ?? 'Usuario creado. Se han enviado las credenciales al correo.';
      },
      error: (err) => {
        this.guardandoUsuario = false;
        const msg = err?.error?.error ?? err?.message ?? err?.statusText;
        this.mensajeUsuario = msg ?? 'Error al crear el usuario.';
      },
    });
  }
}
