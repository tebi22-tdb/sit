package com.sit_titulacion.sit.service

import com.sit_titulacion.sit.domain.AnexoXxxi
import com.sit_titulacion.sit.domain.ConstanciaNoInconveniencia
import com.sit_titulacion.sit.domain.DatosPersonales
import com.sit_titulacion.sit.domain.DatosProyecto
import com.sit_titulacion.sit.domain.DocumentoAdjunto
import com.sit_titulacion.sit.domain.Documentos
import com.sit_titulacion.sit.domain.Egresado
import com.sit_titulacion.sit.domain.HistorialEstado
import com.sit_titulacion.sit.repository.EgresadoRepository
import com.sit_titulacion.sit.web.api.dto.AnexoDto
import com.sit_titulacion.sit.web.api.dto.ConstanciaDto
import com.sit_titulacion.sit.web.api.dto.DatosPersonalesDto
import com.sit_titulacion.sit.web.api.dto.DatosProyectoDto
import com.sit_titulacion.sit.web.api.dto.DepartamentoListItemDto
import com.sit_titulacion.sit.web.api.dto.DocumentoAdjuntoDto
import com.sit_titulacion.sit.web.api.dto.DocumentosDto
import com.sit_titulacion.sit.web.api.dto.EgresadoDetailDto
import com.sit_titulacion.sit.web.api.dto.EgresadoListItemDto
import com.sit_titulacion.sit.web.api.dto.EgresadoRequestDto
import com.sit_titulacion.sit.web.api.dto.EgresadoResponseDto
import org.bson.types.ObjectId
import org.slf4j.LoggerFactory
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.gridfs.GridFsTemplate
import org.springframework.stereotype.Service
import org.springframework.web.multipart.MultipartFile
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFParagraph
import java.io.InputStream
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.ZoneId
import java.time.format.DateTimeParseException
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.font.Standard14Fonts
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.io.File
import java.nio.file.Files

/** Flujo y metadatos del documento adjunto para servir por HTTP. */
data class DocumentoStream(
    val inputStream: InputStream,
    val contentType: String,
    val fileName: String,
)

@Service
class EgresadoService(
    private val egresadoRepository: EgresadoRepository,
    private val gridFsTemplate: GridFsTemplate,
    @Value("\${sit.anexo91.plantilla-docx:}")
    private val anexo91PlantillaDocxPath: String,
    @Value("\${sit.anexo92.plantilla-docx:}")
    private val anexo92PlantillaDocxPath: String,
    @Value("\${sit.anexo93.plantilla-docx:}")
    private val anexo93PlantillaDocxPath: String,
) {
    private val log = LoggerFactory.getLogger(EgresadoService::class.java)

    companion object {
        /** Plantilla oficial ITVO-AC-PR-05-02 (incluida en resources). */
        private const val ANEXO91_TEMPLATE_CLASSPATH = "templates/ITVO-AC-PR-05-02-Solicitud-del-Acto-de-Recepcion-Profesional.docx"
        private const val ANEXO92_TEMPLATE_CLASSPATH = "templates/anexo-9-2.docx"
        private const val ANEXO93_TEMPLATE_CLASSPATH = "templates/anexo-9-3.docx"
    }

    fun crear(datos: EgresadoRequestDto, archivo: MultipartFile?): Egresado {
        val ahora = Instant.now()
        val documentoAdjunto = if (archivo != null && !archivo.isEmpty) {
            val gridFsId = subirArchivo(archivo)
            DocumentoAdjunto(
                gridfs_id = gridFsId,
                nombre_original = archivo.originalFilename ?: "",
                content_type = archivo.contentType ?: "application/octet-stream",
                tamanio_bytes = archivo.size,
                fecha_subida = ahora,
            )
        } else {
            DocumentoAdjunto()
        }

        val egresado = Egresado(
            numero_control = datos.numero_control,
            datos_personales = DatosPersonales(
                nombre = datos.nombre,
                apellido_paterno = datos.apellidoPaterno,
                apellido_materno = datos.apellidoMaterno,
                carrera = datos.carrera,
                nivel = datos.nivel,
                direccion = datos.direccion,
                telefono = datos.telefono,
                correo_electronico = datos.correo_electronico,
            ),
            datos_proyecto = DatosProyecto(
                nombre_proyecto = datos.nombreProyecto ?: "",
                modalidad = datos.modalidad,
                curso_titulacion = datos.cursoTitulacion?.trim()?.lowercase()?.takeIf { it == "si" } ?: "no",
                asesor_interno = datos.asesorInterno?.takeIf { it.isNotBlank() },
                asesor_externo = datos.asesorExterno?.takeIf { it.isNotBlank() },
                director = datos.director?.takeIf { it.isNotBlank() },
                asesor_1 = datos.asesor1?.takeIf { it.isNotBlank() },
                asesor_2 = datos.asesor2?.takeIf { it.isNotBlank() },
            ),
            documentos = Documentos(
                anexo_xxxi = AnexoXxxi(
                    fecha_registro = parseFecha(datos.fechaRegistroAnexo),
                    estado = "pendiente",
                ),
                constancia_no_inconveniencia = ConstanciaNoInconveniencia(
                    fecha_expedicion = parseFecha(datos.fechaExpedicionConstancia),
                    estado = "pendiente",
                ),
            ),
            documento_adjunto = documentoAdjunto,
            estado_general = "registrado",
            historial_estados = listOf(
                HistorialEstado(estado = "registrado", fecha = ahora, observacion = "Registro inicial del alumno"),
            ),
            fechaCreacion = ahora,
            fecha_actualizacion = ahora,
        )
        val guardado = egresadoRepository.save(egresado)
        log.info("Egresado guardado en sit_titulacion.registro: id={}, numero_control={}", guardado.id, guardado.numero_control)
        return guardado
    }

    fun actualizar(id: String, datos: EgresadoRequestDto, archivo: MultipartFile?): Boolean {
        val objectId = try {
            ObjectId(id)
        } catch (_: Exception) {
            return false
        }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return false
        val ahora = Instant.now()
        val documentoAdjunto = when {
            datos.quitarArchivo == true -> DocumentoAdjunto()
            archivo != null && !archivo.isEmpty -> {
                val gridFsId = subirArchivo(archivo)
                DocumentoAdjunto(
                    gridfs_id = gridFsId,
                    nombre_original = archivo.originalFilename ?: "",
                    content_type = archivo.contentType ?: "application/octet-stream",
                    tamanio_bytes = archivo.size,
                    fecha_subida = ahora,
                )
            }
            else -> existente.documento_adjunto
        }
        val actualizado = existente.copy(
            numero_control = datos.numero_control,
            datos_personales = DatosPersonales(
                nombre = datos.nombre,
                apellido_paterno = datos.apellidoPaterno,
                apellido_materno = datos.apellidoMaterno,
                carrera = datos.carrera,
                nivel = datos.nivel,
                direccion = datos.direccion,
                telefono = datos.telefono,
                correo_electronico = datos.correo_electronico,
            ),
            datos_proyecto = DatosProyecto(
                nombre_proyecto = datos.nombreProyecto ?: "",
                modalidad = datos.modalidad,
                curso_titulacion = datos.cursoTitulacion?.trim()?.lowercase()?.takeIf { it == "si" } ?: "no",
                asesor_interno = datos.asesorInterno?.takeIf { it.isNotBlank() },
                asesor_externo = datos.asesorExterno?.takeIf { it.isNotBlank() },
                director = datos.director?.takeIf { it.isNotBlank() },
                asesor_1 = datos.asesor1?.takeIf { it.isNotBlank() },
                asesor_2 = datos.asesor2?.takeIf { it.isNotBlank() },
            ),
            documentos = Documentos(
                anexo_xxxi = AnexoXxxi(
                    fecha_registro = parseFecha(datos.fechaRegistroAnexo),
                    estado = existente.documentos.anexo_xxxi.estado,
                ),
                constancia_no_inconveniencia = ConstanciaNoInconveniencia(
                    fecha_expedicion = parseFecha(datos.fechaExpedicionConstancia),
                    estado = existente.documentos.constancia_no_inconveniencia.estado,
                ),
            ),
            documento_adjunto = documentoAdjunto,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        log.info("Egresado actualizado: id={}, numero_control={}", id, datos.numero_control)
        return true
    }

    fun eliminar(id: String): Boolean {
        val objectId = try {
            ObjectId(id)
        } catch (_: Exception) {
            return false
        }
        if (!egresadoRepository.existsById(objectId)) return false
        egresadoRepository.deleteById(objectId)
        log.info("Egresado eliminado: id={}", id)
        return true
    }

    /** Marca el egresado como "Enviado al departamento académico" (paso 1.1 del flujo). */
    fun marcarEnviadoDepartamentoAcademico(id: String): Boolean {
        val objectId = try { ObjectId(id) } catch (_: Exception) { return false }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return false
        if (existente.fechaEnviadoDepartamentoAcademico != null) return true
        val ahora = Instant.now()
        val actualizado = existente.copy(
            fechaEnviadoDepartamentoAcademico = ahora,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        log.info("Egresado {} marcado como enviado al departamento académico", id)
        return true
    }

    /** Liberar (Departamento académico): marca recibido registro y liberación. Solo Residencia Profesional. */
    fun liberarRegistroLiberacion(id: String): Boolean {
        val objectId = try { ObjectId(id) } catch (_: Exception) { return false }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return false
        if (existente.datos_proyecto.modalidad != "Residencia Profesional") return false
        if (existente.fechaRecibidoRegistroLiberacion != null) return true
        val ahora = Instant.now()
        val actualizado = existente.copy(
            fechaRecibidoRegistroLiberacion = ahora,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        return true
    }

    /** Confirmar (División de estudios): marca confirmación de recibidos. Requiere Liberar previo. */
    fun confirmarRecibidosAnexoXxxiXxxii(id: String): Boolean {
        val objectId = try { ObjectId(id) } catch (_: Exception) { return false }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return false
        if (existente.datos_proyecto.modalidad != "Residencia Profesional") return false
        if (existente.fechaRecibidoRegistroLiberacion == null) return false
        if (existente.fechaConfirmacionRecibidosAnexoXxxiXxxii != null) return true
        val ahora = Instant.now()
        val actualizado = existente.copy(
            fechaConfirmacionRecibidosAnexoXxxiXxxii = ahora,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        return true
    }

    /** Crear y descargar Anexo 9.1 (División): requiere Confirmar previo; marca fecha y devuelve un PDF simple. */
    fun generarAnexo91Pdf(id: String): ByteArray? {
        val objectId = try { ObjectId(id) } catch (_: Exception) { return null }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return null
        if (existente.datos_proyecto.modalidad != "Residencia Profesional") return null
        if (existente.fechaConfirmacionRecibidosAnexoXxxiXxxii == null) return null
        val ahora = Instant.now()
        val actualizado = existente.copy(
            fechaCreacionAnexo91 = ahora,
            // Si se vuelve a generar 9.1, reiniciamos el flujo de los pasos posteriores.
            // Así el usuario vuelve a ver "Entrega 9.1" con el botón de confirmar.
            fechaConfirmacionEntregaAnexo91 = null,
            fechaCreacionAnexo92 = null,
            fechaConfirmacionRecibidoAnexo92 = null,
            fechaSolicitudSinodales = null,
            fechaConfirmacionSinodalesRecibidos = null,
            fechaAgendaActo93 = null,
            fechaCreacionAnexo93 = null,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        // Intenta generar usando la plantilla DOCX oficial. Si falla, cae a la versión PDFBox.
        return generarAnexo91ConPlantillaDocx(actualizado) ?: pdfFormatoAnexo91(actualizado)
    }

    /** Genera el Anexo 9.1 con la plantilla Word oficial (ITVO-AC-PR-05-02) y convierte a PDF (LibreOffice). */
    private fun generarAnexo91ConPlantillaDocx(e: Egresado): ByteArray? {
        val templateStream = abrirPlantillaAnexo91() ?: run {
            log.warn("Anexo 9.1: no se encontró plantilla DOCX (classpath {} ni sit.anexo91.plantilla-docx)", ANEXO91_TEMPLATE_CLASSPATH)
            return null
        }
        return try {
            templateStream.use { input ->
                val docxLleno = XWPFDocument(input).use { doc ->
                    rellenarAnexo91DesdePlantilla(doc, e)
                    ByteArrayOutputStream().also { doc.write(it) }.toByteArray()
                }
                convertirDocxAPdf(docxLleno, "Anexo_9_1_${e.numero_control}")
            }
        } catch (ex: Exception) {
            log.warn("Anexo 9.1 plantilla Word falló: {}", ex.message)
            null
        }
    }

    private fun abrirPlantillaAnexo91(): InputStream? {
        val ruta = anexo91PlantillaDocxPath.trim()
        if (ruta.isNotEmpty()) {
            val f = File(ruta)
            if (f.isFile) return f.inputStream()
            log.warn("sit.anexo91.plantilla-docx no es archivo: {}", ruta)
        }
        return javaClass.classLoader.getResourceAsStream(ANEXO91_TEMPLATE_CLASSPATH)
    }

    /**
     * Sustituye datos del egresado en la plantilla del profesor (texto de ejemplo del ITVO).
     * Une runs por párrafo cuando hace falta para que coincida el texto aunque Word lo fragmente.
     */
    private fun rellenarAnexo91DesdePlantilla(doc: XWPFDocument, e: Egresado) {
        val locale = Locale("es", "MX")
        val fecha = e.fechaCreacionAnexo91?.atZone(ZoneId.systemDefault())?.toLocalDate() ?: LocalDate.now()
        val df = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", locale)
        val fechaTxt = df.format(fecha).uppercase(locale)
        val nombreCompleto = listOf(e.datos_personales.nombre, e.datos_personales.apellido_paterno, e.datos_personales.apellido_materno)
            .filter { !it.isNullOrBlank() }
            .joinToString(" ")
            .trim()
            .uppercase(locale)
        val numeroControl = e.numero_control
        val carrera = e.datos_personales.carrera.uppercase(locale).trim()
        val nivel = e.datos_personales.nivel.uppercase(locale).trim()

        for (p in doc.paragraphs) {
            reemplazarTextoEnParrafoUnido(p, "Fecha: 17 de MARZO de 2021.", "Fecha: $fechaTxt.")
            reemplazarTextoEnParrafoUnido(p, "PROYECTO DE INVESTIGACIÓN", "REPORTE FINAL DE RESIDENCIA PROFESIONAL")
            reemplazarTextoEnParrafoUnido(p, "PROYECTO DE INVESTIGACION", "REPORTE FINAL DE RESIDENCIA PROFESIONAL")
        }
        for (p in doc.paragraphs) {
            if (p.text.contains("Nombre:")) {
                fusionarParrafoATexto(p, "Nombre: $nombreCompleto")
            }
        }
        for (p in doc.paragraphs) {
            if (p.text.contains("No. de control", ignoreCase = true) || p.text.contains("No de control", ignoreCase = true)) {
                val nuevo = p.text.replace(Regex("No\\.?\\s*de\\s*control:\\s*\\d+", RegexOption.IGNORE_CASE), "No. de control: $numeroControl")
                if (nuevo != p.text) fusionarParrafoATexto(p, nuevo)
            }
        }
        reemplazarBloqueCarreraPlantilla(doc, carrera)
        reemplazarBloqueNivelPlantilla(doc, nivel)
    }

    private fun reemplazarTextoEnParrafoUnido(p: XWPFParagraph, buscar: String, reemplazo: String) {
        val sb = StringBuilder()
        for (r in p.runs) sb.append(r.getText(0) ?: "")
        val full = sb.toString()
        if (!full.contains(buscar)) return
        fusionarParrafoATexto(p, full.replace(buscar, reemplazo))
    }

    private fun fusionarParrafoATexto(p: XWPFParagraph, nuevoTexto: String) {
        while (p.runs.isNotEmpty()) p.removeRun(0)
        p.createRun().setText(nuevoTexto)
    }

    /** Plantilla: párrafos "Carrera" + "INGENIERÍA EN " + "AGRONOMÍA" (ejemplo). */
    private fun reemplazarBloqueCarreraPlantilla(doc: XWPFDocument, carrera: String) {
        var i = 0
        while (i < doc.paragraphs.size - 2) {
            val paras = doc.paragraphs
            val t0 = paras[i].text.trim()
            val t1 = paras[i + 1].text.trim()
            val t2 = paras[i + 2].text.trim()
            val bloqueEjemplo = (t0.equals("Carrera", ignoreCase = true) || (t0.startsWith("Carrera", ignoreCase = true) && t0.length <= 12))
                && t1.contains("INGENIER", ignoreCase = true)
                && t2.contains("AGRONOM", ignoreCase = true)
            if (bloqueEjemplo) {
                val pBorrar2 = paras[i + 2]
                val pBorrar1 = paras[i + 1]
                val pos2 = doc.getPosOfParagraph(pBorrar2)
                val pos1 = doc.getPosOfParagraph(pBorrar1)
                fusionarParrafoATexto(paras[i], "Carrera $carrera")
                doc.removeBodyElement(pos2)
                doc.removeBodyElement(pos1)
                continue
            }
            i++
        }
        for (p in doc.paragraphs) {
            val t = p.text
            if (t.startsWith("Carrera", ignoreCase = true) && t.contains("AGRONOM", ignoreCase = true)) {
                fusionarParrafoATexto(p, "Carrera $carrera")
            }
        }
    }

    /** Plantilla: "Nivel" + "LICENCIATURA" en párrafos seguidos. */
    private fun reemplazarBloqueNivelPlantilla(doc: XWPFDocument, nivel: String) {
        var i = 0
        while (i < doc.paragraphs.size - 1) {
            val paras = doc.paragraphs
            val t0 = paras[i].text.trim()
            val t1 = paras[i + 1].text.trim()
            if (t0.equals("Nivel", ignoreCase = true) && t1.contains("LICENCIATURA", ignoreCase = true)) {
                val posSiguiente = doc.getPosOfParagraph(paras[i + 1])
                fusionarParrafoATexto(paras[i], "Nivel $nivel")
                doc.removeBodyElement(posSiguiente)
                continue
            }
            i++
        }
        for (p in doc.paragraphs) {
            val t = p.text.trim()
            if (t.startsWith("Nivel", ignoreCase = true) && t.contains("LICENCIATURA", ignoreCase = true) && t.length < 120) {
                fusionarParrafoATexto(p, "Nivel $nivel")
            }
        }
    }

    private fun convertirDocxAPdf(docxBytes: ByteArray, baseName: String): ByteArray? {
        val soffice = encontrarSoffice() ?: run {
            log.warn("Conversión DOCX→PDF: no se encontró LibreOffice (soffice). Instálalo o añádelo al PATH.")
            return null
        }
        val tmpDir = Files.createTempDirectory("anexo_docx_").toFile().apply { deleteOnExit() }
        val outDir = Files.createTempDirectory("anexo_pdf_").toFile().apply { deleteOnExit() }
        val base = baseName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val docxFile = File(tmpDir, "$base.docx")
        docxFile.writeBytes(docxBytes)
        return try {
            val pb = ProcessBuilder(
                soffice,
                "--headless",
                "--nologo",
                "--nolockcheck",
                "--convert-to",
                "pdf",
                "--outdir",
                outDir.absolutePath,
                docxFile.absolutePath,
            )
            pb.redirectErrorStream(true)
            val proc = pb.start()
            val salida = proc.inputStream.bufferedReader().use { it.readText() }
            val code = proc.waitFor()
            val primaryPdf = File(outDir, "$base.pdf")
            // LibreOffice a veces nombra el PDF distinto o devuelve código ≠0 aunque el archivo exista (sobre todo en Windows).
            val pdfFile = when {
                primaryPdf.isFile -> primaryPdf
                else -> outDir.listFiles()
                    ?.filter { it.isFile && it.name.endsWith(".pdf", ignoreCase = true) }
                    ?.maxByOrNull { it.lastModified() }
            }
            if (pdfFile == null || !pdfFile.isFile) {
                log.warn(
                    "LibreOffice terminó con código {} (esperado {}.pdf). Archivos en outDir: {}. salida={}",
                    code,
                    base,
                    outDir.listFiles()?.joinToString { it.name } ?: "—",
                    salida.take(2000),
                )
                null
            } else {
                if (code != 0) {
                    log.warn("LibreOffice código={} pero se usó PDF generado: {}", code, pdfFile.name)
                }
                pdfFile.readBytes()
            }
        } finally {
            docxFile.delete()
        }
    }

    private fun encontrarSoffice(): String? {
        val os = System.getProperty("os.name").lowercase()
        if (os.contains("win")) {
            listOf(
                """C:\Program Files\LibreOffice\program\soffice.exe""",
                """C:\Program Files (x86)\LibreOffice\program\soffice.exe""",
            ).forEach { path ->
                if (File(path).isFile) return path
            }
            return try {
                val p = ProcessBuilder("cmd.exe", "/c", "where soffice").redirectErrorStream(true).start()
                val line = p.inputStream.bufferedReader().readLine()?.trim()?.takeIf { it.isNotEmpty() }
                p.waitFor()
                line?.takeIf { File(it).isFile }
            } catch (_: Exception) {
                null
            }
        }
        return try {
            val p = ProcessBuilder("which", "soffice").redirectErrorStream(true).start()
            val line = p.inputStream.bufferedReader().readLine()?.trim()
            p.waitFor()
            line?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) {
            null
        }
    }

    /** PDF Anexo 9.1 con formato (similar al documento mostrado). */
    private fun pdfFormatoAnexo91(e: Egresado): ByteArray {
        val p = e.datos_personales
        val nombreCompleto = listOf(p.nombre, p.apellido_paterno, p.apellido_materno).filter { !it.isNullOrBlank() }.joinToString(" ").trim()
        val carrera = p.carrera
        val nivel = p.nivel
        val numeroControl = e.numero_control
        val fecha = (e.fechaCreacionAnexo91 ?: Instant.now()).atZone(ZoneId.systemDefault()).toLocalDate()
        val locale = Locale("es", "MX")
        val df = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", locale)
        val fechaTxtRaw = df.format(fecha)
        val fechaTxt = fechaTxtRaw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }

        val doc = PDDocument()
        val page = PDPage(PDRectangle.LETTER)
        doc.addPage(page)

        // Márgenes solicitados (cm -> pt), LETRA US: 612 x 792 pt
        val marginLeft = 3.5f * 72f / 2.54f  // 3.5 cm
        val marginTop = 2.5f * 72f / 2.54f   // 2.5 cm
        val marginBottom = 2.5f * 72f / 2.54f // 2.5 cm
        val marginRight = 2.5f * 72f / 2.54f  // 2.5 cm
        val margin = marginLeft
        val w = page.mediaBox.width
        val h = page.mediaBox.height
        val top = h - marginTop

        val font = PDType1Font(Standard14Fonts.FontName.HELVETICA)
        val fontBold = PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD)

        PDPageContentStream(doc, page).use { cs ->
            fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
                cs.moveTo(x1, y1); cs.lineTo(x2, y2); cs.stroke()
            }
            fun rect(x: Float, y: Float, rw: Float, rh: Float) {
                cs.addRect(x, y, rw, rh); cs.stroke()
            }
            fun text(font: org.apache.pdfbox.pdmodel.font.PDFont, size: Float, x: Float, y: Float, s: String) {
                cs.beginText()
                cs.setFont(font, size)
                cs.newLineAtOffset(x, y)
                cs.showText(s)
                cs.endText()
            }
            fun centered(font: org.apache.pdfbox.pdmodel.font.PDFont, size: Float, y: Float, s: String) {
                val sw = font.getStringWidth(s) / 1000f * size
                text(font, size, (w - sw) / 2f, y, s)
            }

            fun stringWidth(f: org.apache.pdfbox.pdmodel.font.PDFont, size: Float, s: String): Float =
                f.getStringWidth(s) / 1000f * size

            /** Parte el texto para que no rebalse horizontalmente (evita solapamiento con la columna derecha). */
            fun wrapLines(f: org.apache.pdfbox.pdmodel.font.PDFont, size: Float, maxW: Float, paragraph: String): List<String> {
                val words = paragraph.replace("\n", " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                val out = mutableListOf<String>()
                var cur = StringBuilder()
                for (word in words) {
                    val cand = if (cur.isEmpty()) word else "${cur} $word"
                    if (stringWidth(f, size, cand) <= maxW || cur.isEmpty()) {
                        if (cur.isEmpty()) cur.append(word) else cur.append(' ').append(word)
                    } else {
                        out.add(cur.toString())
                        cur = StringBuilder(word)
                    }
                }
                if (cur.isNotEmpty()) out.add(cur.toString())
                return out
            }

            cs.setLineWidth(0.8f)

            // Encabezado (tabla superior)
            val headerY = top - 62f
            val headerH = 62f
            rect(marginLeft, headerY, w - marginLeft - marginRight, headerH)
            // columnas: logo | texto (con wrap) | codigo/rev/pagina — col3 un poco más angosta para dar aire al centro
            val col1 = 88f
            val col3 = 150f
            line(marginLeft + col1, headerY, marginLeft + col1, headerY + headerH)
            line(w - marginRight - col3, headerY, w - marginRight - col3, headerY + headerH)
            // filas en col3
            line(w - marginRight - col3, headerY + headerH * 2f / 3f, w - marginRight, headerY + headerH * 2f / 3f)
            line(w - marginRight - col3, headerY + headerH * 1f / 3f, w - marginRight, headerY + headerH * 1f / 3f)

            val midPad = 5f
            val midX0 = marginLeft + col1 + midPad
            val midX1 = w - marginRight - col3 - midPad
            val midAvailW = (midX1 - midX0).coerceAtLeast(48f)

            val headerTitleLines = buildList {
                addAll(wrapLines(fontBold, 8.5f, midAvailW, "Nombre del documento: Formato de Solicitud para"))
                addAll(wrapLines(fontBold, 8.5f, midAvailW, "Acto de Recepción Profesional"))
            }
            var yHdrLine = headerY + headerH - 11f
            val minYForIso = headerY + 24f
            for (hl in headerTitleLines) {
                if (yHdrLine < minYForIso) break
                text(fontBold, 8.5f, midX0, yHdrLine, hl)
                yHdrLine -= 10f
            }
            text(font, 8f, midX0, headerY + 9f, "Referencia a la Norma ISO 9001:2015: 8.1, 8.5")

            val rightColX = w - marginRight - col3 + 6f
            text(fontBold, 8.2f, rightColX, headerY + headerH - 16f, "Código: ITVO-AC-PR-05-02")
            text(fontBold, 8.2f, rightColX, headerY + headerH * 2f / 3f - 14f, "Revisión: 2")
            text(fontBold, 8.2f, rightColX, headerY + headerH * 1f / 3f - 14f, "Página 1 de 1")

            // Logo ITVO (imagen real si existe; si no, respaldo textual)
            val logoCellX = marginLeft + 6f
            val logoCellY = headerY + 6f
            val logoCellW = col1 - 12f
            val logoCellH = headerH - 12f
            try {
                val logoPath = "frontend/src/assets/images/logo-itvo.png"
                val f = File(logoPath)
                if (f.exists()) {
                    val logoBytes = f.readBytes()
                    val img = PDImageXObject.createFromByteArray(doc, logoBytes, "logo-itvo")
                    cs.drawImage(img, logoCellX, logoCellY, logoCellW, logoCellH)
                } else {
                    text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 18f, "INSTITUTO")
                    text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 30f, "TECNOLÓGICO")
                    text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 42f, "DE OAXACA")
                }
            } catch (_: Exception) {
                text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 18f, "INSTITUTO")
                text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 30f, "TECNOLÓGICO")
                text(fontBold, 7.5f, marginLeft + 10f, headerY + headerH - 42f, "DE OAXACA")
            }

            // Títulos: más aire bajo el cuadro del encabezado, y entre el título principal y la fecha
            val yTituloAnexo = headerY - 42f
            val yTituloSolicitud = yTituloAnexo - 30f
            val yFechaLinea = yTituloSolicitud - 36f
            centered(font, 10f, yTituloAnexo, "Anexo 9.1 Formato de Solicitud del Acto de Recepción Profesional")
            centered(fontBold, 12f, yTituloSolicitud, "SOLICITUD DE ACTO DE RECEPCIÓN PROFESIONAL")
            text(font, 10f, w - marginRight - 175f, yFechaLinea, "Fecha: $fechaTxt")

            // Cuerpo (destinatario) — debajo de la fecha con separación coherente
            var y = yFechaLinea - 28f
            text(fontBold, 10f, margin, y, "ROMEO ALBERTO ANGELES PEREZ")
            y -= 14f
            text(fontBold, 10f, margin, y, "JEFE DEL DEPARTAMENTO DE SERVICIOS ESCOLARES")
            y -= 14f
            text(fontBold, 10f, margin, y, "PRESENTE.")

            // Párrafo principal (justificado entre márgenes)
            val contentLeftJ = marginLeft
            val contentRightJ = w - marginRight
            val contentWJ = contentRightJ - contentLeftJ
            fun wrapWordsJust(paragraph: String, size: Float): List<List<String>> {
                val words = paragraph.replace("\n", " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                val spaceW = font.getStringWidth(" ") / 1000f * size
                val lines = mutableListOf<MutableList<String>>()
                var current = mutableListOf<String>()
                var currentW = 0f
                for (word in words) {
                    val wordW = font.getStringWidth(word) / 1000f * size
                    val addW = if (current.isEmpty()) wordW else (spaceW + wordW)
                    if (!current.isEmpty() && currentW + addW > contentWJ) {
                        lines += current
                        current = mutableListOf(word)
                        currentW = wordW
                    } else {
                        current += word
                        currentW += addW
                    }
                }
                if (current.isNotEmpty()) lines += current
                return lines
            }
            fun drawJustified(words: List<String>, yLine: Float, size: Float, isLast: Boolean) {
                val spaceW = font.getStringWidth(" ") / 1000f * size
                val wordWidths = words.map { font.getStringWidth(it) / 1000f * size }
                if (words.size <= 1 || isLast) {
                    var x = contentLeftJ
                    for (i in words.indices) {
                        text(font, size, x, yLine, words[i])
                        x += wordWidths[i] + spaceW
                    }
                    return
                }
                val gaps = words.size - 1
                val totalWordsW = wordWidths.sum()
                val actualW = totalWordsW + gaps * spaceW
                val extra = contentWJ - actualW
                val gapExtraPer = extra / gaps
                var x = contentLeftJ
                for (i in words.indices) {
                    text(font, size, x, yLine, words[i])
                    x += wordWidths[i]
                    if (i < words.size - 1) x += spaceW + gapExtraPer
                }
            }

            val paragraphPrincipal =
                "Me permito solicitar se autorice la sustentación del Acto de Recepción Profesional por la Opción TITULACIÓN INTEGRAL (REPORTE FINAL DE RESIDENCIA PROFESIONAL), " +
                    "para obtener mi Título Profesional de ${nivel.uppercase(locale)} en ${carrera.uppercase(locale)} en virtud de haber cubierto los requisitos indispensables para tal efecto."

            val sizeP = 10f
            val leadingP = 14f
            y -= 34f
            val linesP = wrapWordsJust(paragraphPrincipal, sizeP)
            for (i in linesP.indices) {
                drawJustified(linesP[i], y, sizeP, i == linesP.lastIndex)
                y -= leadingP
            }

            // Subrayado solo hasta donde termina el texto (valor en negrita)
            fun underlineHastaTexto(xInicio: Float, yLine: Float, f: org.apache.pdfbox.pdmodel.font.PDFont, size: Float, valor: String) {
                val tw = stringWidth(f, size, valor)
                if (tw > 0.5f) line(xInicio, yLine - 2f, xInicio + tw, yLine - 2f)
            }

            // Campos: Nombre / Firma / No control / Carrera / Nivel
            y -= 42f
            val xValNombre = margin + 52f
            val nomMay = nombreCompleto.uppercase(locale)
            text(font, 10f, margin, y, "Nombre:")
            text(fontBold, 10f, xValNombre, y, nomMay)
            underlineHastaTexto(xValNombre, y, fontBold, 10f, nomMay)

            y -= 28f
            val xValFirma = margin + 52f
            text(font, 10f, margin, y, "Firma:")
            // Sin firma escrita: línea corta fija para rubricar
            line(xValFirma, y - 2f, xValFirma + 130f, y - 2f)

            y -= 28f
            val xValNc = margin + 82f
            text(font, 10f, margin, y, "No. de control:")
            text(fontBold, 10f, xValNc, y, numeroControl)
            underlineHastaTexto(xValNc, y, fontBold, 10f, numeroControl)

            y -= 28f
            val xValCarrera = margin + 52f
            val carMay = carrera.uppercase(locale)
            text(font, 10f, margin, y, "Carrera:")
            text(fontBold, 10f, xValCarrera, y, carMay)
            underlineHastaTexto(xValCarrera, y, fontBold, 10f, carMay)

            y -= 28f
            val xValNivel = margin + 52f
            val nivMay = nivel.uppercase(locale)
            text(font, 10f, margin, y, "Nivel:")
            text(fontBold, 10f, xValNivel, y, nivMay)
            underlineHastaTexto(xValNivel, y, fontBold, 10f, nivMay)

            // Pie de página: evitar solapamiento entre código, leyenda larga y revisión
            val footerY1 = marginBottom - 2f
            val footerAvailW = w - marginLeft - marginRight
            text(font, 7.5f, marginLeft, footerY1, "ITVO-AC-PR-05-02")
            val revStr = "Rev. 2"
            text(font, 7.5f, w - marginRight - stringWidth(font, 7.5f, revStr) - 2f, footerY1, revStr)
            var yFoot = footerY1 - 9f
            for (fl in wrapLines(font, 7.5f, footerAvailW, "Toda copia en PAPEL es un \"Documento No Controlado\" a excepción del original.")) {
                text(font, 7.5f, marginLeft, yFoot, fl)
                yFoot -= 8f
            }
            val pagStr = "Página 1 de 1"
            text(font, 7.5f, w - marginRight - stringWidth(font, 7.5f, pagStr) - 2f, yFoot - 2f, pagStr)
        }

        val out = ByteArrayOutputStream()
        doc.save(out)
        doc.close()
        return out.toByteArray()
    }

    private fun esResidenciaProfesional(e: Egresado): Boolean {
        val m = e.datos_proyecto.modalidad.trim().replace(Regex("\\s+"), " ")
        return m.equals("Residencia Profesional", ignoreCase = true)
    }

    private fun cargarEgresadoPorId(id: String): Egresado? {
        val oid = try { ObjectId(id) } catch (_: Exception) { return null }
        return egresadoRepository.findById(oid).orElse(null)
    }

    private fun parseFechaHoraLocal(s: String): Instant? {
        val t = s.trim()
        if (t.isEmpty()) return null
        return try {
            // `datetime-local` típicamente manda: `YYYY-MM-DDTHH:mm` (sin segundos).
            // `ISO_LOCAL_DATE_TIME` normalmente espera segundos, así que intentamos ambos formatos.
            val dt = try {
                LocalDateTime.parse(t, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
            } catch (_: Exception) {
                LocalDateTime.parse(t, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
            }
            dt.atZone(ZoneId.systemDefault()).toInstant()
        } catch (_: Exception) {
            null
        }
    }

    private fun nombreCompletoMayusEgresado(e: Egresado, locale: Locale): String =
        listOf(e.datos_personales.nombre, e.datos_personales.apellido_paterno, e.datos_personales.apellido_materno)
            .filter { !it.isNullOrBlank() }.joinToString(" ").trim().uppercase(locale)

    /** Reemplazos literales en todo el documento Word (párrafos y tablas). */
    private fun aplicarReemplazosEnDocx(doc: XWPFDocument, reemplazos: List<Pair<String, String>>) {
        val ordenados = reemplazos.sortedByDescending { it.first.length }
        fun procesarParrafo(p: XWPFParagraph) {
            val sb = StringBuilder()
            for (r in p.runs) sb.append(r.getText(0) ?: "")
            var t = sb.toString()
            if (t.isEmpty()) return
            var cambio = false
            for ((a, b) in ordenados) {
                if (t.contains(a)) {
                    t = t.replace(a, b)
                    cambio = true
                }
            }
            if (cambio) fusionarParrafoATexto(p, t)
        }
        for (p in doc.paragraphs) procesarParrafo(p)
        for (table in doc.tables) {
            for (row in table.rows) {
                for (cell in row.tableCells) {
                    for (p in cell.paragraphs) procesarParrafo(p)
                }
            }
        }
    }

    private fun reemplazarProyectoEnParrafos93(doc: XWPFDocument, nombreProyecto: String) {
        val limpio = nombreProyecto.replace("«", "").replace("»", "").trim().ifBlank { "—" }
        val rx = Regex("con el proyecto denominado:[\\s\\S]+?que se realizar", RegexOption.IGNORE_CASE)
        fun proc(p: XWPFParagraph) {
            val sb = StringBuilder()
            for (r in p.runs) sb.append(r.getText(0) ?: "")
            val t = sb.toString()
            if (!t.contains("con el proyecto denominado", ignoreCase = true)) return
            if (!t.contains("que se realizar", ignoreCase = true)) return
            val nuevo = rx.replace(t, "con el proyecto denominado: «$limpio», que se realizar")
            if (nuevo != t) fusionarParrafoATexto(p, nuevo)
        }
        for (p in doc.paragraphs) proc(p)
        for (table in doc.tables) {
            for (row in table.rows) {
                for (cell in row.tableCells) {
                    for (p in cell.paragraphs) proc(p)
                }
            }
        }
    }

    private fun abrirPlantillaAnexo92(): InputStream? {
        val ruta = anexo92PlantillaDocxPath.trim()
        if (ruta.isNotEmpty()) {
            val input = abrirPlantillaDesdeRuta(ruta, "sit.anexo92.plantilla-docx")
            if (input != null) return input
        }
        return javaClass.classLoader.getResourceAsStream(ANEXO92_TEMPLATE_CLASSPATH)
    }

    private fun abrirPlantillaAnexo93(): InputStream? {
        val ruta = anexo93PlantillaDocxPath.trim()
        if (ruta.isNotEmpty()) {
            val input = abrirPlantillaDesdeRuta(ruta, "sit.anexo93.plantilla-docx")
            if (input != null) return input
        }
        return javaClass.classLoader.getResourceAsStream(ANEXO93_TEMPLATE_CLASSPATH)
    }

    private fun abrirPlantillaDesdeRuta(rutaRaw: String, nombreCampo: String): InputStream? {
        val ruta = rutaRaw.trim().trim('"')
        if (ruta.isEmpty()) return null

        // Soporta separadores / y \ y rutas con comillas.
        val candidatos = linkedSetOf(
            ruta,
            ruta.replace('/', '\\'),
            ruta.replace('\\', '/'),
        )

        for (c in candidatos) {
            val f = File(c)
            if (f.isFile) return f.inputStream()
        }

        log.warn("{} no es archivo: {}", nombreCampo, rutaRaw)
        return null
    }

    private fun rellenarPlantillaAnexo92(doc: XWPFDocument, e: Egresado) {
        val locale = Locale("es", "MX")
        val fechaTxt = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", locale)
            .format(Instant.now().atZone(ZoneId.systemDefault()).toLocalDate())
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
        val nom = nombreCompletoMayusEgresado(e, locale)
        aplicarReemplazosEnDocx(
            doc,
            listOf(
                "12 de marzo de 2020" to fechaTxt,
                "LEONARDO ALTAMIRANO ARANGO" to nom,
            ),
        )
    }

    private fun rellenarPlantillaAnexo93(doc: XWPFDocument, e: Egresado, fechaActo: Instant) {
        val locale = Locale("es", "MX")
        val nom = nombreCompletoMayusEgresado(e, locale)
        val carrera = e.datos_personales.carrera.uppercase(locale).trim()
        val nc = e.numero_control
        val proyecto = e.datos_proyecto.nombre_proyecto.trim().ifBlank { "—" }
        val z = fechaActo.atZone(ZoneId.systemDefault())
        aplicarReemplazosEnDocx(
            doc,
            listOf(
                "ALONSO ELA? MARTA?NEZ RAMA?REZ" to nom,
                "14920310" to nc,
                "INGENIERIA FORESTAL" to carrera,
                " del 2021" to " del ${z.year}",
                "PROYECTO DE INVESTIGACIÓN" to "REPORTE FINAL DE RESIDENCIA PROFESIONAL",
                "PROYECTO DE INVESTIGACION" to "REPORTE FINAL DE RESIDENCIA PROFESIONAL",
            ),
        )
        reemplazarProyectoEnParrafos93(doc, proyecto)
    }

    fun confirmarEntregaAnexo91(id: String): Boolean {
        val e = cargarEgresadoPorId(id) ?: return false
        if (!esResidenciaProfesional(e)) return false
        if (e.fechaCreacionAnexo91 == null || e.fechaConfirmacionEntregaAnexo91 != null) return false
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaConfirmacionEntregaAnexo91 = ahora, fecha_actualizacion = ahora))
        return true
    }

    fun confirmarRecibidoAnexo92(id: String): Boolean {
        val e = cargarEgresadoPorId(id) ?: return false
        if (!esResidenciaProfesional(e)) return false
        if (e.fechaConfirmacionEntregaAnexo91 == null || e.fechaCreacionAnexo92 == null || e.fechaConfirmacionRecibidoAnexo92 != null) return false
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaConfirmacionRecibidoAnexo92 = ahora, fecha_actualizacion = ahora))
        return true
    }

    fun solicitarSinodales(id: String): Boolean {
        val e = cargarEgresadoPorId(id) ?: return false
        if (!esResidenciaProfesional(e)) return false
        if (e.fechaConfirmacionRecibidoAnexo92 == null || e.fechaSolicitudSinodales != null) return false
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaSolicitudSinodales = ahora, fecha_actualizacion = ahora))
        return true
    }

    fun confirmarSinodalesRecibidos(id: String): Boolean {
        val e = cargarEgresadoPorId(id) ?: return false
        if (!esResidenciaProfesional(e)) return false
        if (e.fechaSolicitudSinodales == null || e.fechaConfirmacionSinodalesRecibidos != null) return false
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaConfirmacionSinodalesRecibidos = ahora, fecha_actualizacion = ahora))
        return true
    }

    fun agendarActo93(id: String, fechaHoraRaw: String): Boolean {
        val e = cargarEgresadoPorId(id) ?: return false
        if (!esResidenciaProfesional(e)) return false
        if (e.fechaConfirmacionSinodalesRecibidos == null || e.fechaAgendaActo93 != null) return false
        val instant = parseFechaHoraLocal(fechaHoraRaw) ?: return false
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaAgendaActo93 = instant, fecha_actualizacion = ahora))
        return true
    }

    fun generarAnexo92Pdf(id: String): ByteArray? = generarAnexo92PdfDiagnostico(id).first

    /**
     * Igual que [generarAnexo93PdfDiagnostico]: devuelve motivo cuando no hay PDF (para el JSON 400 del API).
     */
    fun generarAnexo92PdfDiagnostico(id: String): Pair<ByteArray?, String> {
        val e = cargarEgresadoPorId(id) ?: return null to "Egresado no encontrado."
        if (!esResidenciaProfesional(e)) {
            return null to "Solo aplica a modalidad «Residencia Profesional» (actual: «${e.datos_proyecto.modalidad}»)."
        }
        if (e.fechaConfirmacionEntregaAnexo91 == null) {
            return null to "Falta confirmar la entrega del anexo 9.1 antes de generar el 9.2."
        }
        val input = abrirPlantillaAnexo92()
        if (input == null) {
            log.warn("Anexo 9.2: plantilla no encontrada; usando formato PDF básico de respaldo.")
            val fallback = pdfFormatoAnexo92Basico(e)
            marcarAnexo92Creado(e)
            return fallback to "OK"
        }
        return try {
            val pdf = input.use { stream ->
                val docxLleno = XWPFDocument(stream).use { doc ->
                    rellenarPlantillaAnexo92(doc, e)
                    ByteArrayOutputStream().also { doc.write(it) }.toByteArray()
                }
                convertirDocxAPdf(docxLleno, "Anexo_9_2_${e.numero_control}")
            } ?: run {
                log.warn("Anexo 9.2: LibreOffice no generó PDF; usando formato básico de respaldo.")
                pdfFormatoAnexo92Basico(e)
            }
            marcarAnexo92Creado(e)
            pdf to "OK"
        } catch (ex: Exception) {
            log.warn("Anexo 9.2: error con plantilla/conversión ({}). Usando fallback PDF.", ex.message, ex)
            val fallback = pdfFormatoAnexo92Basico(e)
            marcarAnexo92Creado(e)
            fallback to "OK"
        }
    }

    private fun marcarAnexo92Creado(e: Egresado) {
        val ahora = Instant.now()
        egresadoRepository.save(e.copy(fechaCreacionAnexo92 = ahora, fecha_actualizacion = ahora))
    }

    /**
     * Respaldo de 9.2 cuando no hay plantilla DOCX o falla LibreOffice.
     * Mantiene el flujo operativo y permite descargar PDF siempre.
     */
    private fun pdfFormatoAnexo92Basico(e: Egresado): ByteArray {
        val doc = PDDocument()
        val page = PDPage(PDRectangle.LETTER)
        doc.addPage(page)
        val out = ByteArrayOutputStream()
        val locale = Locale("es", "MX")
        val fecha = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", locale)
            .format(Instant.now().atZone(ZoneId.systemDefault()).toLocalDate())
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
        val nombre = nombreCompletoMayusEgresado(e, locale)
        val carrera = e.datos_personales.carrera.uppercase(locale)

        PDPageContentStream(doc, page).use { cs ->
            var y = page.mediaBox.height - 70f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 15f)
            cs.newLineAtOffset(70f, y)
            cs.showText("CONSTANCIA 9.2")
            cs.endText()

            y -= 34f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA), 11f)
            cs.newLineAtOffset(70f, y)
            cs.showText("Fecha: $fecha")
            cs.endText()

            y -= 28f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA), 11f)
            cs.newLineAtOffset(70f, y)
            cs.showText("Se hace constar que el egresado:")
            cs.endText()

            y -= 20f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD), 12f)
            cs.newLineAtOffset(70f, y)
            cs.showText(nombre)
            cs.endText()

            y -= 20f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA), 11f)
            cs.newLineAtOffset(70f, y)
            cs.showText("No. de control: ${e.numero_control}")
            cs.endText()

            y -= 18f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA), 11f)
            cs.newLineAtOffset(70f, y)
            cs.showText("Carrera: $carrera")
            cs.endText()

            y -= 34f
            cs.beginText()
            cs.setFont(PDType1Font(Standard14Fonts.FontName.HELVETICA), 11f)
            cs.newLineAtOffset(70f, y)
            cs.showText("Documento generado automáticamente por el SIT (formato de respaldo).")
            cs.endText()
        }

        doc.save(out)
        doc.close()
        return out.toByteArray()
    }

    fun generarAnexo93Pdf(id: String): ByteArray? {
        return generarAnexo93PdfDiagnostico(id).first
    }

    /**
     * Genera Anexo 9.3 con motivo para depurar (cuando regresa null desde el endpoint).
     * first = bytes (o null), second = motivo explicativo.
     */
    fun generarAnexo93PdfDiagnostico(id: String): Pair<ByteArray?, String> {
        val e = cargarEgresadoPorId(id) ?: return null to "Egresado no encontrado."
        if (!esResidenciaProfesional(e)) return null to "Solo aplica a Residencia Profesional."

        val agenda = e.fechaAgendaActo93 ?: return null to "Agenda 9.3 no disponible. Agendar el acto antes."

        val input = abrirPlantillaAnexo93() ?: run {
            log.warn("Anexo 9.3: plantilla no encontrada")
            return null to "Plantilla DOCX de 9.3 no encontrada (config o classpath)."
        }

        return try {
            val docxLleno = input.use { stream ->
                XWPFDocument(stream).use { doc ->
                    rellenarPlantillaAnexo93(doc, e, agenda)
                    ByteArrayOutputStream().also { doc.write(it) }.toByteArray()
                }
            }

            val pdf = convertirDocxAPdf(docxLleno, "Anexo_9_3_${e.numero_control}")
                ?: return null to "LibreOffice no pudo convertir el DOCX a PDF."

            val ahora = Instant.now()
            val actualizado = e.copy(fechaCreacionAnexo93 = ahora, fecha_actualizacion = ahora)
            egresadoRepository.save(actualizado)
            pdf to "OK"
        } catch (ex: Exception) {
            log.warn("Anexo 9.3: {}", ex.message)
            null to "Error generando Anexo 9.3: ${ex.message ?: ex::class.simpleName}"
        }
    }

    fun listarTodos(): List<EgresadoResponseDto> =
        egresadoRepository.findAll().map { e ->
            EgresadoResponseDto(
                id = e.id?.toString() ?: "",
                numero_control = e.numero_control,
            )
        }

    /** Lista para el panel izquierdo: recientes primero, opcional filtro por número de control. */
    fun listarParaLista(numeroControlFilter: String?): List<EgresadoListItemDto> {
        val lista = if (numeroControlFilter.isNullOrBlank()) {
            egresadoRepository.findAll().sortedByDescending { it.id }
        } else {
            egresadoRepository.findByNumeroControlContaining(numeroControlFilter.trim())
                .sortedByDescending { it.id }
        }
        log.info("listarParaLista: encontrados {} egresados en DB", lista.size)
        return lista.map { e ->
            val p = e.datos_personales
            val nombreCompleto = listOf(p.nombre, p.apellido_paterno, p.apellido_materno)
                .filter { !it.isNullOrBlank() }
                .joinToString(" ")
                .ifBlank { "—" }
            val carrera = p.carrera.ifBlank { "—" }
            EgresadoListItemDto(
                id = e.id?.toString() ?: "",
                numero_control = e.numero_control,
                nombre = nombreCompleto,
                carrera = carrera,
            )
        }
    }

    /** Conteos para pestañas del departamento académico (pendientes, aprobados, todos). */
    fun contarParaDepartamento(): Map<String, Any> {
        val pendientes = egresadoRepository.findByEnviadoDepartamentoPendientes().size
        val aprobados = egresadoRepository.findByRecibidoRegistroLiberacion().size
        val todos = egresadoRepository.findByEnviadoDepartamentoTodos().size
        return mapOf(
            "pendientes" to pendientes,
            "aprobados" to aprobados,
            "todos" to todos,
        )
    }

    /** Lista para departamento académico por estado: pendientes, aprobados, todos. */
    fun listarParaDepartamento(estado: String): List<DepartamentoListItemDto> {
        val formatter = DateTimeFormatter.ISO_INSTANT
        val lista = when (estado.trim().lowercase()) {
            "pendientes" -> egresadoRepository.findByEnviadoDepartamentoPendientes()
            "aprobados" -> egresadoRepository.findByRecibidoRegistroLiberacion()
            else -> egresadoRepository.findByEnviadoDepartamentoTodos()
        }
        return lista.map { e ->
            val p = e.datos_personales
            val nombre = listOf(p.nombre, p.apellido_paterno, p.apellido_materno).filter { !it.isNullOrBlank() }.joinToString(" ").ifBlank { "—" }
            val estadoRevision = if (e.fechaRecibidoRegistroLiberacion != null) "aprobado" else "pendiente"
            DepartamentoListItemDto(
                id = e.id?.toString() ?: "",
                nombre = nombre,
                numeroControl = e.numero_control,
                modalidad = e.datos_proyecto.modalidad,
                fechaActualizacion = formatter.format(e.fecha_actualizacion),
                fechaEnviadoDepartamento = e.fechaEnviadoDepartamentoAcademico?.let { formatter.format(it) },
                estadoRevision = estadoRevision,
            )
        }
    }

    fun obtenerPorId(id: String): EgresadoDetailDto? {
        val objectId = try {
            ObjectId(id)
        } catch (_: Exception) {
            return null
        }
        return egresadoRepository.findById(objectId).orElse(null)?.let { toDetailDto(it) }
    }

    /** Obtener por número de control (respaldo cuando el id de la lista no coincide). */
    fun obtenerPorNumeroControl(numeroControl: String): EgresadoDetailDto? {
        if (numeroControl.isBlank()) return null
        return egresadoRepository.findByNumeroControl(numeroControl.trim())?.let { toDetailDto(it) }
    }

    /** Obtiene el documento adjunto del egresado para descarga/visualización. Devuelve null si no hay documento. */
    fun obtenerDocumentoAdjunto(egresadoId: String): DocumentoStream? {
        val oid = try { ObjectId(egresadoId) } catch (_: Exception) { return null }
        val egresado = egresadoRepository.findById(oid).orElse(null) ?: return null
        val adj = egresado.documento_adjunto
        val gridfsId = adj.gridfs_id ?: return null
        if (adj.nombre_original.isBlank()) return null
        val file = gridFsTemplate.findOne(Query.query(Criteria.where("_id").`is`(gridfsId))) ?: return null
        val resource = gridFsTemplate.getResource(file)
        return DocumentoStream(
            inputStream = resource.inputStream,
            contentType = adj.content_type.ifBlank { "application/octet-stream" },
            fileName = adj.nombre_original,
        )
    }

    /**
     * Sustituye el documento adjunto (GridFS) por un archivo nuevo. Elimina el binario anterior si existía.
     * Usado desde departamento académico al subir corrección del expediente.
     */
    fun reemplazarDocumentoAdjunto(egresadoId: String, archivo: MultipartFile): Boolean {
        if (archivo.isEmpty) return false
        val objectId = try {
            ObjectId(egresadoId)
        } catch (_: Exception) {
            return false
        }
        val existente = egresadoRepository.findById(objectId).orElse(null) ?: return false
        val ahora = Instant.now()
        val viejoGridId = existente.documento_adjunto.gridfs_id
        val nuevoGridId = subirArchivo(archivo)
        if (viejoGridId != null) {
            try {
                gridFsTemplate.delete(Query.query(Criteria.where("_id").`is`(viejoGridId)))
            } catch (e: Exception) {
                log.warn("No se pudo eliminar el archivo GridFS anterior id={}", viejoGridId, e)
            }
        }
        val nuevoAdj = DocumentoAdjunto(
            gridfs_id = nuevoGridId,
            nombre_original = archivo.originalFilename ?: "documento",
            content_type = archivo.contentType ?: "application/octet-stream",
            tamanio_bytes = archivo.size,
            fecha_subida = ahora,
        )
        val actualizado = existente.copy(
            documento_adjunto = nuevoAdj,
            fecha_actualizacion = ahora,
        )
        egresadoRepository.save(actualizado)
        log.info("Documento adjunto reemplazado egresadoId={}", egresadoId)
        return true
    }

    private fun toDetailDto(e: Egresado): EgresadoDetailDto {
        val p = e.datos_personales
        val doc = e.documentos
        val formatter = DateTimeFormatter.ISO_INSTANT
        return EgresadoDetailDto(
            id = e.id?.toString() ?: "",
            numero_control = e.numero_control,
            datos_personales = DatosPersonalesDto(
                nombre = p.nombre,
                apellido_paterno = p.apellido_paterno,
                apellido_materno = p.apellido_materno ?: "",
                carrera = p.carrera,
                nivel = p.nivel,
                direccion = p.direccion,
                telefono = p.telefono,
                correo_electronico = p.correo_electronico,
            ),
            datos_proyecto = DatosProyectoDto(
                nombre_proyecto = e.datos_proyecto.nombre_proyecto,
                modalidad = e.datos_proyecto.modalidad,
                curso_titulacion = e.datos_proyecto.curso_titulacion,
                asesor_interno = e.datos_proyecto.asesor_interno,
                asesor_externo = e.datos_proyecto.asesor_externo,
                director = e.datos_proyecto.director,
                asesor_1 = e.datos_proyecto.asesor_1,
                asesor_2 = e.datos_proyecto.asesor_2,
            ),
            documentos = DocumentosDto(
                anexo_xxxi = doc.anexo_xxxi.let { AnexoDto(it.fecha_registro?.let { formatter.format(it) }, it.estado) },
                constancia_no_inconveniencia = doc.constancia_no_inconveniencia.let { ConstanciaDto(it.fecha_expedicion?.let { formatter.format(it) }, it.estado) },
            ),
            documento_adjunto = e.documento_adjunto.let { adj ->
                if (adj.nombre_original.isNotBlank() || adj.tamanio_bytes > 0) {
                    DocumentoAdjuntoDto(nombre_original = adj.nombre_original, tamanio_bytes = adj.tamanio_bytes)
                } else null
            },
            estado_general = e.estado_general,
            fecha_creacion = e.fechaCreacion.let { formatter.format(it) },
            fecha_actualizacion = e.fecha_actualizacion.let { formatter.format(it) },
            fecha_enviado_departamento_academico = e.fechaEnviadoDepartamentoAcademico?.let { formatter.format(it) },
            fecha_recibido_registro_liberacion = e.fechaRecibidoRegistroLiberacion?.let { formatter.format(it) },
            fecha_confirmacion_recibidos_anexo_xxxi_xxxii = e.fechaConfirmacionRecibidosAnexoXxxiXxxii?.let { formatter.format(it) },
            fecha_creacion_anexo_9_1 = e.fechaCreacionAnexo91?.let { formatter.format(it) },
            fecha_confirmacion_entrega_anexo_9_1 = e.fechaConfirmacionEntregaAnexo91?.let { formatter.format(it) },
            fecha_creacion_anexo_9_2 = e.fechaCreacionAnexo92?.let { formatter.format(it) },
            fecha_confirmacion_recibido_anexo_9_2 = e.fechaConfirmacionRecibidoAnexo92?.let { formatter.format(it) },
            fecha_solicitud_sinodales = e.fechaSolicitudSinodales?.let { formatter.format(it) },
            fecha_confirmacion_sinodales_recibidos = e.fechaConfirmacionSinodalesRecibidos?.let { formatter.format(it) },
            fecha_agenda_acto_9_3 = e.fechaAgendaActo93?.let { formatter.format(it) },
            fecha_creacion_anexo_9_3 = e.fechaCreacionAnexo93?.let { formatter.format(it) },
        )
    }

    private fun subirArchivo(archivo: MultipartFile): ObjectId {
        val id = gridFsTemplate.store(
            archivo.inputStream,
            archivo.originalFilename ?: "documento",
            archivo.contentType ?: "application/octet-stream",
            null,
        )
        return id as ObjectId
    }

    private fun parseFecha(s: String?): Instant? {
        if (s.isNullOrBlank()) return null
        return try {
            LocalDate.parse(s).atStartOfDay(ZoneOffset.UTC).toInstant()
        } catch (_: DateTimeParseException) {
            null
        }
    }
}
