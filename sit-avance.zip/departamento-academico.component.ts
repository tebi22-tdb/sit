import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HeaderComponent } from '../../layout/header/header.component';
import { EgresadoService, DepartamentoListItem, DepartamentoCounts } from '../../services/egresado.service';
/**

 */
type TabEstado = 'pendientes' | 'en_correccion' | 'aprobados' | 'todos';
@Component({
  selector: 'app-departamento-academico',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HeaderComponent],
  templateUrl: './departamento-academico.component.html',
  styleUrl: './departamento-academico.component.css',
})
export class DepartamentoAcademicoComponent implements OnInit {
  tabActivo: TabEstado = 'pendientes';
  counts: DepartamentoCounts = { pendientes: 0, en_correccion: 0, aprobados: 0, todos: 0 };
  lista: DepartamentoListItem[] = [];
  cargando = true;
  error = '';
  /** ID del egresado mientras se ejecuta Liberar (evita doble clic). */
  liberandoId: string | null = null;
  /** Número de control para buscar (solo pestaña Todos). */
  searchNumeroControl = '';
  /** Filtro aplicado al hacer clic en Buscar. */
  filtroNumeroControl = '';

  constructor(
    private egresadoService: EgresadoService,
    private router: Router,
  ) {}

  /** Abre Revisión de documento (solo para modalidades que no son Residencia Profesional). */
  irARevision(item: DepartamentoListItem): void {
    if (item.modalidad === 'Residencia Profesional') return;
    this.router.navigate(['/departamento-academico/revision', item.id]);
  }

  /** Lista a mostrar: en "Todos" filtrada por número de control si hay búsqueda. */
  get listaVisible(): DepartamentoListItem[] {
    if (this.tabActivo !== 'todos' || !this.filtroNumeroControl.trim()) {
      return this.lista;
    }
    const term = this.filtroNumeroControl.trim().toLowerCase();
    return this.lista.filter((item) => item.numero_control.toLowerCase().includes(term));
  }

  aplicarBusqueda(): void {
    this.filtroNumeroControl = this.searchNumeroControl.trim();
  }

  ngOnInit(): void {
    this.cargarCounts();
    this.cargarLista();
  }

  cargarCounts(): void {
    this.egresadoService.getDepartamentoCounts().subscribe({
      next: (c) => {
        this.counts = c;
      },
      error: () => {},
    });
  }

  cargarLista(): void {
    this.error = '';
    this.cargando = true;
    this.egresadoService.listarDepartamento(this.tabActivo).subscribe({
      next: (items) => {
        this.lista = items;
        this.cargando = false;
      },
      error: () => {
        this.error = 'No se pudo cargar la lista.';
        this.cargando = false;
      },
    });
  }

  cambiarTab(tab: TabEstado): void {
    this.tabActivo = tab;
    this.filtroNumeroControl = '';
    if (tab !== 'en_correccion') {
      this.cargarLista();
    } else {
      this.lista = [];
      this.cargando = false;
    }
  }

  /** Liberar (marca recibido registro y liberación). Solo Residencia Profesional; el registro pasa a Aprobados. */
  liberar(id: string): void {
    this.error = '';
    this.liberandoId = id;
    this.egresadoService.liberar(id).subscribe({
      next: () => {
        this.liberandoId = null;
        this.cargarCounts();
        this.cargarLista();
      },
      error: (err: { error?: { error?: string; message?: string }; message?: string }) => {
        this.liberandoId = null;
        const msg = err?.error?.error ?? err?.error?.message ?? err?.message;
        this.error = msg ? `No se pudo liberar: ${msg}` : 'No se pudo liberar. Solo aplica a Residencia Profesional.';
      },
    });
  }

  /** Nombre a mostrar: viene del backend; si falta o está vacío, usa número de control. */
  nombreDisplay(item: DepartamentoListItem): string {
    const n = item.nombre?.trim();
    if (n) return n;
    return `Solicitud ${item.numero_control}`;
  }

  /** Fecha en que se recibió (enviado al departamento académico): DD/MM/YYYY. */
  fechaRecepcion(item: DepartamentoListItem): string {
    const iso = item.fecha_enviado_departamento_academico;
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    const dia = d.getDate().toString().padStart(2, '0');
    const mes = (d.getMonth() + 1).toString().padStart(2, '0');
    const anio = d.getFullYear();
    return `${dia}/${mes}/${anio}`;
  }

  /** Fecha de última modificación: DD/MM/YYYY. */
  ultimoCambio(item: DepartamentoListItem): string {
    const iso = item.fecha_actualizacion;
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    const dia = d.getDate().toString().padStart(2, '0');
    const mes = (d.getMonth() + 1).toString().padStart(2, '0');
    const anio = d.getFullYear();
    return `${dia}/${mes}/${anio}`;
  }
}
