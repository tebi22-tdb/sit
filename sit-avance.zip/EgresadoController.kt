package com.sit_titulacion.sit.web.api

import com.sit_titulacion.sit.config.UsuarioPrincipal
import com.sit_titulacion.sit.repository.EgresadoRepository
import com.sit_titulacion.sit.service.EgresadoService
import com.sit_titulacion.sit.service.UsuarioService
import com.sit_titulacion.sit.web.api.dto.DepartamentoListItemDto
import com.sit_titulacion.sit.web.api.dto.EgresadoDetailDto
import com.sit_titulacion.sit.web.api.dto.EgresadoListItemDto
import com.sit_titulacion.sit.web.api.dto.EgresadoRequestDto
import com.sit_titulacion.sit.web.api.dto.EgresadoResponseDto
import com.sit_titulacion.sit.web.api.dto.AgendarActoRequestDto
import com.sit_titulacion.sit.web.api.dto.CreateRevisionRequestDto
import com.sit_titulacion.sit.web.api.dto.RevisionDto
import com.sit_titulacion.sit.service.RevisionService
import com.sit_titulacion.sit.service.DocumentoStream
import com.sit_titulacion.sit.service.EmailService
import org.springframework.core.env.Environment
import org.springframework.core.io.InputStreamResource
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import org.springframework.core.io.ByteArrayResource
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RequestPart
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.multipart.MultipartFile
import org.bson.types.ObjectId
import org.slf4j.LoggerFactory

@RestController
@RequestMapping("/api/egresados")
class EgresadoController(
    private val egresadoService: EgresadoService,
    private val egresadoRepository: EgresadoRepository,
    private val usuarioService: UsuarioService,
    private val emailService: EmailService,
    private val revisionService: RevisionService,
    private val env: Environment,
) {
    private val log = LoggerFactory.getLogger(EgresadoController::class.java)

    /** Diagnóstico: base de datos, colección y cantidad de documentos. */
    @GetMapping("/diagnostico")
    fun diagnostico(): ResponseEntity<Map<String, Any>> {
        val dbName = env.getProperty("spring.data.mongodb.database") ?: env.getProperty("spring.data.mongodb.uri")?.substringAfterLast("/")?.substringBefore("?") ?: "test"
        val collectionName = "registro"
        val count = egresadoRepository.count()
        return ResponseEntity.ok(mapOf(
            "mensaje" to "Configuración actual del backend",
            "base_de_datos" to dbName,
            "coleccion" to collectionName,
            "documentos_en_coleccion" to count,
            "donde_ver_en_compass" to "En Compass: 77.37.74.122:27017 → base '$dbName' → colección '$collectionName'",
        ))
    }

    @GetMapping
    fun listar(
        @RequestParam(required = false) numero_control: String?,
        @RequestParam(required = false) fecha_desde: String?,
        @RequestParam(required = false) fecha_hasta: String?,
        @RequestParam(required = false) tipo_filtro: String?,
    ): ResponseEntity<List<EgresadoListItemDto>> {
        val desde = parseFechaParam(fecha_desde)
        val hasta = parseFechaParam(fecha_hasta, endOfDay = true)
        val tipo = when (tipo_filtro?.trim()?.lowercase()) {
            "anexo_xxxi", "anexo" -> "anexo_xxxi"
            "constancia" -> "constancia"
            else -> null
        }
        // En esta versión del servicio solo se soporta filtro por número de control.
        // (Los parámetros de fecha se aceptan pero se ignoran para no romper compatibilidad de la API.)
        val lista = egresadoService.listarParaLista(numero_control)
        return ResponseEntity.ok(lista)
    }

    /** Conteos para pestañas del departamento académico. Solo rol academico. */
    @GetMapping("/departamento/counts")
    fun contarDepartamento(@AuthenticationPrincipal principal: UsuarioPrincipal?): ResponseEntity<*> {
        if (principal == null) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        if (principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        return ResponseEntity.ok(egresadoService.contarParaDepartamento())
    }

    /** Lista para departamento académico (Pendientes, Aprobados, Todos). Solo rol academico. */
    @GetMapping("/departamento")
    fun listarDepartamento(
        @RequestParam(required = false, defaultValue = "pendientes") estado: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        if (principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        val lista = egresadoService.listarParaDepartamento(estado)
        return ResponseEntity.ok<List<DepartamentoListItemDto>>(lista)
    }

    /**
     * Autorización para pasos del flujo 9.1-9.3:
     * - Si el usuario es `egresado`, debe ser el dueño del registro (mismo `numero_control` que `username`).
     * - Para cualquier otro rol autenticado (coordinación/división/etc. desde `home`), permitimos operar sobre el
     *   registro seleccionado. El backend asegura además que el "paso" corresponda (fechas nulas/no nulas).
     */
    private fun egresadoEsPropio(principal: UsuarioPrincipal?, egresadoId: String): Boolean {
        if (principal == null) return false
        val rol = principal.getRol().trim().lowercase()
        if (rol == "egresado") {
            val oid = try { ObjectId(egresadoId) } catch (_: Exception) { return false }
            val e = egresadoRepository.findById(oid).orElse(null) ?: return false
            return e.numero_control.trim() == principal.username.trim()
        }
        return true
    }

    private fun parseFechaParam(s: String?, endOfDay: Boolean = false): java.time.Instant? {
        if (s.isNullOrBlank()) return null
        return try {
            val date = java.time.LocalDate.parse(s)
            if (endOfDay) {
                date.atTime(23, 59, 59, 999_999_999).atOffset(java.time.ZoneOffset.UTC).toInstant()
            } else {
                date.atStartOfDay(java.time.ZoneOffset.UTC).toInstant()
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Respaldo: obtener por número de control (evita 404 si el id en lista era de otra base). */
    @GetMapping("/por-numero/{numeroControl}")
    fun obtenerPorNumeroControl(@PathVariable numeroControl: String): ResponseEntity<*> {
        val detalle = egresadoService.obtenerPorNumeroControl(numeroControl)
        return if (detalle != null) ResponseEntity.ok(detalle)
        else ResponseEntity.notFound().build<Void>()
    }

    /** Seguimiento del egresado: devuelve su propio registro (por egresadoId o por número de control). */
    @GetMapping("/mi-seguimiento")
    fun miSeguimiento(@AuthenticationPrincipal principal: UsuarioPrincipal?): ResponseEntity<*> {
        if (principal == null) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        val numeroControl = principal.username.trim().ifBlank { null } ?: return ResponseEntity.notFound().build<Void>()
        // Implementación simple: buscar por número de control.
        // (Evita dependencias a rutas/métodos opcionales y asegura que el seguimiento siempre funcione.)
        val detalle = egresadoService.obtenerPorNumeroControl(numeroControl)
        return if (detalle != null) ResponseEntity.ok(detalle)
        else ResponseEntity.notFound().build<Void>()
    }

    @GetMapping("/{id}")
    fun obtenerPorId(@PathVariable id: String): ResponseEntity<*> {
        val detalle = egresadoService.obtenerPorId(id)
        return if (detalle != null) ResponseEntity.ok(detalle)
        else ResponseEntity.notFound().build<Void>()
    }

    /** Descarga/visualiza el documento adjunto del egresado (PDF/Word). Solo rol academico. */
    @GetMapping("/{id}/documento")
    fun obtenerDocumento(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null || principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        val doc = egresadoService.obtenerDocumentoAdjunto(id) ?: return ResponseEntity.notFound().build<Void>()
        val headers = HttpHeaders().apply {
            set(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + doc.fileName.replace("\"", "%22") + "\"")
        }
        val mediaType = try { MediaType.parseMediaType(doc.contentType) } catch (_: Exception) { MediaType.APPLICATION_OCTET_STREAM }
        return ResponseEntity.ok()
            .headers(headers)
            .contentType(mediaType)
            .body<InputStreamResource>(InputStreamResource(doc.inputStream))
    }

    /**
     * Sustituye el documento adjunto del egresado por el archivo enviado (reemplaza el anterior en GridFS).
     * Solo rol academico.
     */
    @PostMapping("/{id}/documento", consumes = [MediaType.MULTIPART_FORM_DATA_VALUE])
    fun reemplazarDocumentoAdjunto(
        @PathVariable id: String,
        @RequestPart("archivo") archivo: MultipartFile,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null || principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        if (archivo.isEmpty) {
            return ResponseEntity.badRequest().body(mapOf("error" to "Archivo vacío"))
        }
        val ok = egresadoService.reemplazarDocumentoAdjunto(id, archivo)
        return if (ok) {
            ResponseEntity.ok(mapOf("ok" to true, "mensaje" to "Documento actualizado"))
        } else {
            ResponseEntity.status(HttpStatus.NOT_FOUND).body(mapOf("error" to "Egresado no encontrado"))
        }
    }

    @PostMapping(consumes = [MediaType.MULTIPART_FORM_DATA_VALUE])
    fun crear(
        @RequestPart("datos") datos: EgresadoRequestDto,
        @RequestPart(value = "archivo", required = false) archivo: MultipartFile? = null,
    ): ResponseEntity<EgresadoResponseDto> {
        val egresado = egresadoService.crear(datos, archivo)
        val oid = egresado.id
        var credencialesEnviadas: Boolean? = null
        var avisoCredenciales: String? = null
        if (oid != null) {
            try {
                val (usuarioLogin, passwordPlana) =
                    usuarioService.crearOVincularUsuarioEgresado(egresado.numero_control, oid)
                val correoDestino = listOf(
                    datos.correo_electronico?.trim(),
                    egresado.datos_personales.correo_electronico?.trim(),
                ).firstOrNull { !it.isNullOrBlank() } ?: ""
                if (passwordPlana.isBlank()) {
                    credencialesEnviadas = false
                    avisoCredenciales =
                        "Ya existía un usuario con ese número de control: no se generó contraseña nueva ni correo. " +
                            "Si el alumno nunca tuvo acceso, revisa usuarios duplicados o usa otro número de control."
                    log.info(
                        "Alta egresado {}: usuario ya existía; no se envía correo de credenciales.",
                        egresado.numero_control,
                    )
                } else if (correoDestino.isBlank()) {
                    credencialesEnviadas = false
                    avisoCredenciales =
                        "Usuario creado, pero no hay correo electrónico en el registro; no se pudo enviar la contraseña por email."
                    log.warn(
                        "Alta egresado {}: sin correo_electronico en payload ni en persona guardada.",
                        egresado.numero_control,
                    )
                } else {
                    try {
                        emailService.enviarCredenciales(correoDestino, usuarioLogin, passwordPlana)
                        credencialesEnviadas = true
                        avisoCredenciales =
                            "Se enviaron usuario y contraseña a $correoDestino (revisa bandeja de entrada y spam)."
                        log.info("Credenciales enviadas por correo a {} (usuario={})", correoDestino, usuarioLogin)
                    } catch (e: Exception) {
                        credencialesEnviadas = false
                        avisoCredenciales =
                            "No se pudo enviar el correo (SMTP): ${e.message ?: "error desconocido"}. " +
                                "Revisa spring.mail y la contraseña de aplicación de Gmail."
                        log.error(
                            "Egresado creado pero falló SMTP al enviar credenciales a {} (usuario={}): {}",
                            correoDestino,
                            usuarioLogin,
                            e.message,
                            e,
                        )
                    }
                }
            } catch (e: Exception) {
                credencialesEnviadas = false
                avisoCredenciales = "Error al crear usuario del egresado: ${e.message ?: e.javaClass.simpleName}"
                log.error(
                    "Egresado guardado pero falló creación/vínculo de usuario para numero_control={}: {}",
                    egresado.numero_control,
                    e.message,
                    e,
                )
            }
        }
        val response = EgresadoResponseDto(
            id = egresado.id?.toString() ?: "",
            numero_control = egresado.numero_control,
            credenciales_enviadas_correo = credencialesEnviadas,
            aviso_credenciales = avisoCredenciales,
        )
        return ResponseEntity.status(HttpStatus.CREATED).body(response)
    }

    @PostMapping("/{id}", consumes = [MediaType.MULTIPART_FORM_DATA_VALUE])
    fun actualizar(
        @PathVariable id: String,
        @RequestPart("datos") datos: EgresadoRequestDto,
        @RequestPart(value = "archivo", required = false) archivo: MultipartFile? = null,
    ): ResponseEntity<*> {
        return if (egresadoService.actualizar(id, datos, archivo)) {
            ResponseEntity.ok().build<Void>()
        } else {
            ResponseEntity.notFound().build<Void>()
        }
    }

    @PostMapping("/eliminar/{id}")
    fun eliminar(@PathVariable id: String): ResponseEntity<*> {
        return if (egresadoService.eliminar(id)) {
            ResponseEntity.noContent().build<Void>()
        } else {
            ResponseEntity.notFound().build<Void>()
        }
    }

    /** Marca el egresado como "Enviado al departamento académico" (paso 1.1 del seguimiento). */
    @PostMapping("/{id}/enviar-departamento-academico")
    fun enviarDepartamentoAcademico(@PathVariable id: String): ResponseEntity<*> {
        return if (egresadoService.marcarEnviadoDepartamentoAcademico(id)) {
            ResponseEntity.ok().build<Void>()
        } else {
            ResponseEntity.notFound().build<Void>()
        }
    }

    /** Liberar (Departamento académico). Solo rol academico. */
    @PostMapping("/liberar/{id}")
    fun liberar(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null || principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        return if (egresadoService.liberarRegistroLiberacion(id)) {
            ResponseEntity.ok().build<Void>()
        } else {
            ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo liberar. Solo aplica a Residencia Profesional."))
        }
    }

    /** Confirmar recibidos (División de estudios). */
    @PostMapping("/{id}/confirmar-recibidos-anexo-xxxi-xxxii")
    fun confirmarRecibidos(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        if (principal.getRol().trim().lowercase() == "egresado") return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.confirmarRecibidosAnexoXxxiXxxii(id)) {
            ResponseEntity.ok().build<Void>()
        } else {
            ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo confirmar. Requiere liberación previa y aplica solo a Residencia Profesional."))
        }
    }

    @PostMapping("/{id}/confirmar-entrega-anexo-9-1")
    fun confirmarEntregaAnexo91(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.confirmarEntregaAnexo91(id)) ResponseEntity.ok().build<Void>()
        else ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo confirmar la entrega del 9.1."))
    }

    @PostMapping("/{id}/confirmar-recibido-anexo-9-2")
    fun confirmarRecibidoAnexo92(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.confirmarRecibidoAnexo92(id)) ResponseEntity.ok().build<Void>()
        else ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo confirmar Recibido 9.2."))
    }

    @PostMapping("/{id}/solicitar-sinodales")
    fun solicitarSinodales(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.solicitarSinodales(id)) ResponseEntity.ok().build<Void>()
        else ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo registrar la solicitud de sinodales."))
    }

    @PostMapping("/{id}/confirmar-sinodales-recibidos")
    fun confirmarSinodalesRecibidos(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.confirmarSinodalesRecibidos(id)) ResponseEntity.ok().build<Void>()
        else ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo confirmar sinodales recibidos."))
    }

    @PostMapping("/{id}/agendar-acto-9-3", consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun agendarActo93(
        @PathVariable id: String,
        @RequestBody body: AgendarActoRequestDto,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        return if (egresadoService.agendarActo93(id, body.fecha_hora)) ResponseEntity.ok().build<Void>()
        else ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "Fecha u hora no válida o paso no disponible."))
    }

    @GetMapping("/{id}/anexo-9-2")
    fun descargarAnexo92(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        val (pdf, motivo) = egresadoService.generarAnexo92PdfDiagnostico(id)
        val bytes = pdf ?: return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to motivo))
        val headers = HttpHeaders().apply {
            set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Anexo-9.2-$id.pdf\"")
        }
        return ResponseEntity.ok()
            .headers(headers)
            .contentType(MediaType.APPLICATION_PDF)
            .body<ByteArrayResource>(ByteArrayResource(bytes))
    }

    @GetMapping("/{id}/anexo-9-3")
    fun descargarAnexo93(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (!egresadoEsPropio(principal, id)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        val (pdf, motivo) = egresadoService.generarAnexo93PdfDiagnostico(id)
        val bytes = pdf ?: return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to motivo))
        val headers = HttpHeaders().apply {
            set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Anexo-9.3-$id.pdf\"")
        }
        return ResponseEntity.ok()
            .headers(headers)
            .contentType(MediaType.APPLICATION_PDF)
            .body<ByteArrayResource>(ByteArrayResource(bytes))
    }

    /** Crear y descargar Anexo 9.1 (PDF). */
    @GetMapping("/{id}/anexo-9-1")
    fun descargarAnexo91(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null) return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        if (principal.getRol().trim().lowercase() == "egresado") return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        val pdf = egresadoService.generarAnexo91Pdf(id)
            ?: return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("error" to "No se pudo crear el Anexo 9.1. Requiere confirmación previa."))
        val headers = HttpHeaders().apply {
            set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Anexo-9.1-$id.pdf\"")
        }
        return ResponseEntity.ok()
            .headers(headers)
            .contentType(MediaType.APPLICATION_PDF)
            .body<ByteArrayResource>(ByteArrayResource(pdf))
    }

    /** Lista revisiones del egresado (solo rol academico). */
    @GetMapping("/{id}/revisiones")
    fun listarRevisiones(
        @PathVariable id: String,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null || principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        val lista = revisionService.listarPorEgresado(id)
        return ResponseEntity.ok(lista)
    }

    /** Crea una revisión (Enviar revisión con observaciones). Solo rol academico. */
    @PostMapping(value = ["/{id}/revisiones"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun crearRevision(
        @PathVariable id: String,
        @RequestBody body: CreateRevisionRequestDto,
        @AuthenticationPrincipal principal: UsuarioPrincipal?,
    ): ResponseEntity<*> {
        if (principal == null || principal.getRol().trim().lowercase() != "academico") {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build<Void>()
        }
        val creada = revisionService.crear(id, body, principal.getRol())
        return if (creada != null) ResponseEntity.status(HttpStatus.CREATED).body(creada)
        else ResponseEntity.notFound().build<Void>()
    }
}
