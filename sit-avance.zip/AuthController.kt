package com.sit_titulacion.sit.web.api

import com.sit_titulacion.sit.config.UsuarioPrincipal
import org.springframework.context.annotation.Profile
import org.springframework.http.ResponseEntity
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

data class UsuarioActualDto(val username: String, val rol: String)
data class HashRequest(val password: String? = null)
data class HashResponse(val hash: String)

@RestController
@RequestMapping("/api/auth")
class AuthController(
    private val passwordEncoder: PasswordEncoder,
) {

    /**
     * Solo disponible con perfil "dev". Genera hash BCrypt para crear el usuario coordinador en MongoDB.
     */
    @Profile("dev")
    @PostMapping("/hash")
    fun hash(@RequestBody body: HashRequest): ResponseEntity<HashResponse> {
        body.password
            ?.takeIf { it.isNotBlank() }
            ?.let { pwd ->
                @Suppress("USELESS_CAST")
                val hash = passwordEncoder.encode(pwd) as String
                return ResponseEntity.ok(HashResponse(hash))
            }
        return ResponseEntity.badRequest().build()
    }

    @GetMapping("/me")
    fun me(@AuthenticationPrincipal principal: UsuarioPrincipal?): ResponseEntity<UsuarioActualDto> {
        val auth = principal ?: (SecurityContextHolder.getContext().authentication?.principal as? UsuarioPrincipal)
        if (auth == null) {
            return ResponseEntity.status(401).build()
        }
        return ResponseEntity.ok(UsuarioActualDto(
            username = auth.username,
            rol = auth.getRol(),
        ))
    }
}
