package com.sit_titulacion.sit.config

import com.fasterxml.jackson.databind.ObjectMapper
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.AuthenticationFailureHandler
import org.springframework.security.web.authentication.AuthenticationSuccessHandler
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.CorsConfigurationSource
import org.springframework.web.cors.UrlBasedCorsConfigurationSource

@Configuration
@EnableWebSecurity
class SecurityConfig {

    @Bean
    fun securityFilterChain(http: HttpSecurity): SecurityFilterChain {
        http
            .cors { it.configurationSource(corsConfigurationSource()) }
            .csrf { it.disable() }
            .authorizeHttpRequests { auth ->
                auth
                    .requestMatchers("/api/auth/login").permitAll()
                    .requestMatchers("/api/auth/hash").permitAll()
                    .requestMatchers("/api/auth/me").authenticated()
                    .requestMatchers("/api/auth/logout").authenticated()
                    .requestMatchers("/api/**").authenticated()
                    .anyRequest().permitAll()
            }
            .formLogin { form ->
                form.loginProcessingUrl("/api/auth/login")
                    .usernameParameter("username")
                    .passwordParameter("password")
                    .successHandler(jsonLoginSuccessHandler())
                    .failureHandler(jsonLoginFailureHandler())
            }
            .logout { logout ->
                logout.logoutUrl("/api/auth/logout")
                    .logoutSuccessHandler { _, response, _ ->
                        response.contentType = "application/json;charset=UTF-8"
                        response.characterEncoding = "UTF-8"
                        response.writer.write("""{"ok":true}""")
                    }
            }
        return http.build()
    }

    private fun jsonLoginSuccessHandler(): AuthenticationSuccessHandler {
        return AuthenticationSuccessHandler { _: HttpServletRequest, response: HttpServletResponse, authentication ->
            val principal = authentication.principal as? UsuarioPrincipal
            val rol = principal?.getRol() ?: "egresado"
            val username = authentication.name
            response.contentType = "application/json;charset=UTF-8"
            response.characterEncoding = "UTF-8"
            response.writer.write(ObjectMapper().writeValueAsString(mapOf(
                "username" to username,
                "rol" to rol,
            )))
        }
    }

    private fun jsonLoginFailureHandler(): AuthenticationFailureHandler {
        return AuthenticationFailureHandler { _: HttpServletRequest, response: HttpServletResponse, _ ->
            response.status = HttpServletResponse.SC_UNAUTHORIZED
            response.contentType = "application/json;charset=UTF-8"
            response.characterEncoding = "UTF-8"
            response.writer.write("""{"error":"Credenciales inválidas"}""")
        }
    }

    @Bean
    fun passwordEncoder(): PasswordEncoder = BCryptPasswordEncoder()

    @Bean
    fun corsConfigurationSource(): CorsConfigurationSource {
        val config = CorsConfiguration().apply {
            allowCredentials = true
            addAllowedOrigin("http://localhost:4200")
            addAllowedOriginPattern("https://*")
            addAllowedOriginPattern("http://*")
            addAllowedHeader("*")
            addAllowedMethod("*")
        }
        val source = UrlBasedCorsConfigurationSource()
        source.registerCorsConfiguration("/**", config)
        return source
    }
}
