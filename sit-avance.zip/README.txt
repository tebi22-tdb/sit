Plantilla Anexo 9.1 (ITVO-AC-PR-05-02)
=====================================

Archivo incluido: ITVO-AC-PR-05-02-Solicitud-del-Acto-de-Recepcion-Profesional.docx

Si el profesor entrega una versión nueva, sustituye ese archivo aquí (mismo nombre)
o configura en application.properties:

  sit.anexo91.plantilla-docx=C:/ruta/completa/al/archivo.docx

Requisito en el servidor: LibreOffice (soffice) instalado para convertir DOCX → PDF.
